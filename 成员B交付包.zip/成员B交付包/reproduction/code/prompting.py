"""Render the frozen QA templates without including answers or audit metadata."""

import argparse
import json
import sys
from pathlib import Path

from data_common import DataError, PROJECT_ROOT, load_jsonl, require, text_sha256


def build_prompt(record, templates_dir=None):
    templates_dir = Path(templates_dir) if templates_dir else PROJECT_ROOT / "configs" / "prompts"
    condition = record.get("condition")
    num_docs = record.get("num_docs")
    require(isinstance(record.get("question"), str) and bool(record["question"].strip()), "Missing question")
    require(isinstance(record.get("ctxs"), list), "Missing ctxs")
    require(type(num_docs) is int and len(record["ctxs"]) == num_docs, "num_docs and ctxs disagree")
    if condition == "closedbook":
        require(num_docs == 0, "Closed-book must have no documents")
        name = "closedbook_qa.prompt"
        arguments = {"question": record["question"]}
    else:
        require(num_docs > 0 and condition is not None, "Context QA requires a named condition and documents")
        name = "qa.prompt"
        documents = []
        for index, ctx in enumerate(record["ctxs"]):
            require(isinstance(ctx.get("title"), str) and isinstance(ctx.get("text"), str), "Invalid title/text")
            documents.append("Document [{}](Title: {}) {}".format(index + 1, ctx["title"], ctx["text"]))
        arguments = {"question": record["question"], "search_results": "\n".join(documents)}
    # Match upstream prompting.py: UTF-8 text-mode read, strip final newlines only.
    with (templates_dir / name).open("r", encoding="utf-8") as stream:
        template = stream.read().rstrip("\n")
    return template.format(**arguments)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="One B input JSONL file")
    parser.add_argument("--output", type=Path, help="UTF-8 JSONL output; omit for stdout")
    parser.add_argument("--limit", type=int, help="Render only the first N inputs")
    args = parser.parse_args()
    try:
        if args.limit is not None:
            require(args.limit > 0, "--limit must be positive")
        records = load_jsonl(args.input)
        if args.limit is not None:
            records = records[:args.limit]
        output = []
        for record in records:
            prompt = build_prompt(record)
            output.append({"qid": record["qid"], "condition": record["condition"],
                           "prompt": prompt, "prompt_sha256": text_sha256(prompt),
                           "messages": [{"role": "user", "content": prompt}]})
        text = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in output)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_bytes(text.encode("utf-8"))
        else:
            if hasattr(sys.stdout, "reconfigure"):
                sys.stdout.reconfigure(encoding="utf-8")
            sys.stdout.write(text)
    except (DataError, OSError, KeyError) as error:
        print("ERROR: {}".format(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
