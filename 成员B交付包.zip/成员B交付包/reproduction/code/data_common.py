"""Shared I/O and fixed experiment constants; Python 3.9+, standard library only."""

import gzip
import hashlib
import json
import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SEED = 42
SAMPLE_SIZE = 100
TRIAL_SIZE = 10
POPULATION_SIZE = 2655
SOURCE_FILES = {
    "10doc_start": "qa_data/10_total_documents/nq-open-10_total_documents_gold_at_0.jsonl.gz",
    "10doc_middle": "qa_data/10_total_documents/nq-open-10_total_documents_gold_at_4.jsonl.gz",
    "10doc_end": "qa_data/10_total_documents/nq-open-10_total_documents_gold_at_9.jsonl.gz",
    "oracle": "qa_data/nq-open-oracle.jsonl.gz",
}
CONDITIONS = (
    {"condition": "10doc_start", "file": "10doc/首.jsonl", "num_docs": 10,
     "gold_position": "首", "gold_index": 0, "source": "10doc_start"},
    {"condition": "10doc_middle", "file": "10doc/中.jsonl", "num_docs": 10,
     "gold_position": "中", "gold_index": 4, "source": "10doc_middle"},
    {"condition": "10doc_end", "file": "10doc/尾.jsonl", "num_docs": 10,
     "gold_position": "尾", "gold_index": 9, "source": "10doc_end"},
    {"condition": "5doc_start", "file": "5doc/首.jsonl", "num_docs": 5,
     "gold_position": "首", "gold_index": 0, "source": "10doc_start"},
    {"condition": "5doc_middle", "file": "5doc/中.jsonl", "num_docs": 5,
     "gold_position": "中", "gold_index": 2, "source": "10doc_start"},
    {"condition": "5doc_end", "file": "5doc/尾.jsonl", "num_docs": 5,
     "gold_position": "尾", "gold_index": 4, "source": "10doc_start"},
    {"condition": "closedbook", "file": "closedbook.jsonl", "num_docs": 0,
     "gold_position": None, "gold_index": None, "source": "10doc_start"},
    {"condition": "oracle", "file": "oracle.jsonl", "num_docs": 1,
     "gold_position": None, "gold_index": 0, "source": "oracle"},
)
SAMPLING_ALGORITHM = "random.Random(42).sample(range(2655), 100); preserve selection order"
PROMPT_FILES = ("qa.prompt", "closedbook_qa.prompt")


class DataError(ValueError):
    """An input violates the frozen experiment contract."""


def require(test, message):
    if not test:
        raise DataError(message)


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def text_sha256(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def jsonl_bytes(records):
    return "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":"),
                              allow_nan=False) + "\n" for row in records).encode("utf-8")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def load_json(path):
    with Path(path).open("r", encoding="utf-8") as stream:
        return json.load(stream, object_pairs_hook=_unique_object)


def load_jsonl(path):
    path = Path(path)
    opener = gzip.open if path.suffix == ".gz" else open
    records = []
    with opener(path, "rt", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            require(bool(line.strip()), "{}:{}: blank JSONL line".format(path, line_number))
            try:
                record = json.loads(line, object_pairs_hook=_unique_object)
            except (ValueError, TypeError) as error:
                raise DataError("{}:{}: {}".format(path, line_number, error)) from error
            require(isinstance(record, dict), "{}:{}: expected JSON object".format(path, line_number))
            records.append(record)
    return records


def qid_for(row_index):
    return "nq-open-10-{:05d}".format(row_index)


def relative_path(path, parent=PROJECT_ROOT):
    return Path(os.path.relpath(str(Path(path).resolve()), str(Path(parent).resolve()))).as_posix()


def find_source_root(explicit=None):
    if explicit:
        candidates = [Path(explicit).resolve()]
    else:
        candidates = [PROJECT_ROOT / "official_repo" / "lost-in-the-middle-main",
                      PROJECT_ROOT.parent / "lost-in-the-middle-main" / "lost-in-the-middle-main"]
    for root in candidates:
        if all((root / name).is_file() for name in SOURCE_FILES.values()):
            return root.resolve()
    raise DataError("Cannot find official data. Supply --source-root pointing to the repository containing qa_data/.")


def doc_content(ctx):
    return tuple(ctx.get(key) for key in ("title", "text", "hasanswer", "isgold"))


def load_and_audit_sources(source_root):
    """Check every source row before extracting any selected samples."""
    sources = {}
    source_summary = {}
    for name, relative in SOURCE_FILES.items():
        path = source_root / relative
        rows = load_jsonl(path)
        require(len(rows) == POPULATION_SIZE, "{}: expected {} rows, found {}".format(relative, POPULATION_SIZE, len(rows)))
        num_docs = 1 if name == "oracle" else 10
        gold_index = {"10doc_start": 0, "10doc_middle": 4, "10doc_end": 9, "oracle": 0}[name]
        shapes = {}
        for row_index, row in enumerate(rows):
            label = "{}:row[{}]".format(relative, row_index)
            require(isinstance(row.get("question"), str) and bool(row["question"].strip()), label + ": empty question")
            require(isinstance(row.get("answers"), list) and bool(row["answers"])
                    and all(isinstance(a, str) and bool(a.strip()) for a in row["answers"]), label + ": invalid answers")
            ctxs = row.get("ctxs")
            require(isinstance(ctxs, list) and len(ctxs) == num_docs, label + ": wrong document count")
            for ctx in ctxs:
                require(isinstance(ctx, dict), label + ": invalid document")
                require(all(isinstance(ctx.get(key), str) and bool(ctx[key].strip()) for key in ("title", "text")),
                        label + ": empty title/text")
                require(type(ctx.get("isgold")) is bool and type(ctx.get("hasanswer")) is bool,
                        label + ": missing boolean flags")
                shape = ",".join(sorted(ctx))
                shapes[shape] = shapes.get(shape, 0) + 1
            require([i for i, ctx in enumerate(ctxs) if ctx["isgold"]] == [gold_index], label + ": wrong gold position")
            require([i for i, ctx in enumerate(ctxs) if ctx["hasanswer"]] == [gold_index], label + ": wrong hasanswer flags")
        sources[name] = rows
        source_summary[relative] = {"rows": len(rows), "sha256": file_sha256(path), "ctx_field_shapes": shapes}
    base = sources["10doc_start"]
    require(len({row["question"] for row in base}) == len(base), "Mother file contains duplicate questions; cannot silently deduplicate.")
    for name in ("10doc_middle", "10doc_end", "oracle"):
        for row_index, (mother, other) in enumerate(zip(base, sources[name])):
            label = "{}:row[{}]".format(name, row_index)
            require((mother["question"], mother["answers"]) == (other["question"], other["answers"]), label + ": question/answers alignment mismatch")
            require([doc_content(c) for c in mother["ctxs"] if c["isgold"]]
                    == [doc_content(c) for c in other["ctxs"] if c["isgold"]], label + ": gold content mismatch")
            if name != "oracle":
                require([doc_content(c) for c in mother["ctxs"] if not c["isgold"]]
                        == [doc_content(c) for c in other["ctxs"] if not c["isgold"]], label + ": distractor content/order mismatch")
    return sources, source_summary


def template_snapshot(source_root):
    snapshots = {}
    for name in PROMPT_FILES:
        local = PROJECT_ROOT / "configs" / "prompts" / name
        upstream = source_root / "src" / "lost_in_the_middle" / "prompts" / name
        require(local.read_bytes() == upstream.read_bytes(), "Prompt differs from official template: " + name)
        snapshots[name] = file_sha256(local)
    return snapshots


def write_bytes(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
