"""Independently validate B inputs against official source records and frozen IDs."""

import argparse
import copy
import platform
import random
import re
import string
import sys
from pathlib import Path

from data_common import (
    CONDITIONS, DataError, POPULATION_SIZE, PROJECT_ROOT, SAMPLE_SIZE,
    SAMPLING_ALGORITHM, SEED, SOURCE_FILES, TRIAL_SIZE, doc_content,
    file_sha256, find_source_root, json_bytes, jsonl_bytes, load_and_audit_sources,
    load_json, load_jsonl, qid_for, require, template_snapshot, text_sha256, write_bytes,
)
from prompting import build_prompt


INPUT_FIELDS = {"qid", "question", "answers", "num_docs", "gold_position", "gold_index",
                "condition", "src_file", "src_row_index", "ctxs"}
PROVENANCE_FIELDS = {"src_file", "src_row_index", "src_ctx_index"}


def normalized_answer(value):
    # Diagnostic only; D implements the actual model-output score.
    lowered = "".join(c for c in value.lower() if c not in string.punctuation)
    return " ".join(re.sub(r"\b(a|an|the)\b", " ", lowered).split())


class Checks:
    def __init__(self):
        self.count = 0

    def check(self, value, message):
        self.count += 1
        require(value, message)


def validate_data(data_dir, source_root=None):
    """Read-only validation. Raise DataError on the first concrete inconsistency."""
    data_dir = Path(data_dir).resolve()
    checks = Checks()
    check = checks.check
    manifest = load_json(data_dir / "sample_100" / "manifest.json")
    check(isinstance(manifest, dict), "manifest: expected object")
    check(type(manifest.get("schema_version")) is int and manifest["schema_version"] == 1,
          "manifest: unsupported schema")
    for key, value in (("seed", SEED), ("population_size", POPULATION_SIZE),
                       ("sample_size", SAMPLE_SIZE), ("trial_size", TRIAL_SIZE)):
        check(type(manifest.get(key)) is int and manifest[key] == value, "manifest: wrong " + key)
    check(manifest.get("sampling_algorithm") == SAMPLING_ALGORITHM, "manifest: wrong sampling algorithm")
    indices = manifest.get("selected_source_row_indices")
    check(isinstance(indices, list) and len(indices) == SAMPLE_SIZE,
          "manifest: invalid selected source rows")
    check(all(type(i) is int and 0 <= i < POPULATION_SIZE for i in indices),
          "manifest: source row index out of range/type")
    check(indices == random.Random(SEED).sample(range(POPULATION_SIZE), SAMPLE_SIZE),
          "manifest: source row selection differs from seed=42")
    check(len(set(indices)) == SAMPLE_SIZE, "manifest: duplicate source row")
    check(manifest.get("config_sha256") == file_sha256(PROJECT_ROOT / "configs" / "experiment_config.md"),
          "Frozen experiment config changed since data preparation")
    if source_root is None:
        relative = manifest.get("source_root_relative_to_project")
        check(isinstance(relative, str), "manifest: missing source root")
        source_root = find_source_root(PROJECT_ROOT / relative)
    else:
        source_root = find_source_root(source_root)
    sources, source_summary = load_and_audit_sources(source_root)
    check(manifest.get("sources") == source_summary, "Official source hash/schema/row count changed")
    check(manifest.get("prompt_template_sha256") == template_snapshot(source_root),
          "Prompt template snapshot changed")
    check(manifest.get("model_execution_status") == "not_run_by_member_B",
          "manifest must not claim a model run")
    check(manifest.get("baseline_field_convention") == {
        "closedbook": {"num_docs": 0, "gold_position": None, "gold_index": None, "ctxs": []},
        "oracle": {"num_docs": 1, "gold_position": None, "gold_index": 0},
        "discriminator": "condition; do not treat baseline gold_position=null as a location condition",
    }, "manifest: baseline convention changed")
    qids = [qid_for(i) for i in indices]
    qids_path = data_dir / "sample_100" / "qids.txt"
    check(qids_path.read_text(encoding="utf-8").splitlines() == qids, "Fixed qid list differs from source-row mapping")
    trial_qids_path = data_dir / "trial10" / "qids.txt"
    check(trial_qids_path.read_text(encoding="utf-8").splitlines() == qids[:TRIAL_SIZE],
          "Trial qid list is not the fixed first 10 samples")
    check(manifest.get("trial_qids") == qids[:TRIAL_SIZE], "manifest: wrong trial qids")
    samples_path = data_dir / "sample_100" / "samples.jsonl"
    samples = load_jsonl(samples_path)
    check(len(samples) == SAMPLE_SIZE, "samples.jsonl: wrong row count")
    for item, row_index in zip(samples, indices):
        source = sources["10doc_start"][row_index]
        check(item == {"qid": qid_for(row_index), "src_file": SOURCE_FILES["10doc_start"],
                       "src_row_index": row_index, "question": source["question"], "answers": source["answers"]},
              "samples.jsonl: source mapping/question/answers mismatch at " + qid_for(row_index))
    descriptors = manifest.get("input_files")
    check(isinstance(descriptors, list) and len(descriptors) == 2 * len(CONDITIONS),
          "manifest: expected exactly 16 full/trial condition files")
    check(all(isinstance(item, dict) and isinstance(item.get("file"), str) for item in descriptors),
          "manifest: invalid file descriptor")
    descriptor_map = {item["file"]: item for item in descriptors}
    check(len(descriptor_map) == len(descriptors), "manifest: duplicate input file")
    expected_paths = {prefix + spec["file"] for prefix in ("", "trial10/") for spec in CONDITIONS}
    check(set(descriptor_map) == expected_paths, "manifest: unexpected/missing condition file")
    upstream_templates = {}
    for name in ("qa.prompt", "closedbook_qa.prompt"):
        with (source_root / "src" / "lost_in_the_middle" / "prompts" / name).open("r", encoding="utf-8") as stream:
            upstream_templates[name] = stream.read().rstrip("\n")
    datasets = {"full": {}, "trial10": {}}
    prompt_audit = []
    prompt_examples = {}
    input_file_summaries = []
    no_answer_in_gold = set()
    for split, prefix, selected_indices in (("full", "", indices), ("trial10", "trial10/", indices[:TRIAL_SIZE])):
        for spec in CONDITIONS:
            relative = prefix + spec["file"]
            path = data_dir / relative
            descriptor = descriptor_map[relative]
            rows = load_jsonl(path)
            check(len(rows) == len(selected_indices), relative + ": wrong row count")
            check([row.get("qid") for row in rows] == [qid_for(i) for i in selected_indices],
                  relative + ": qid order/uniqueness differs from frozen sample list")
            actual_hash = file_sha256(path)
            check(descriptor == {"file": relative, "split": split, "condition": spec["condition"],
                                 "rows": len(selected_indices), "num_docs": spec["num_docs"],
                                 "gold_position": spec["gold_position"], "gold_index": spec["gold_index"],
                                 "sha256": actual_hash}, relative + ": file hash/descriptor mismatch")
            characters = []
            for row, row_index in zip(rows, selected_indices):
                label = relative + ": " + qid_for(row_index)
                source = sources[spec["source"]][row_index]
                source_file = SOURCE_FILES[spec["source"]]
                check(set(row) == INPUT_FIELDS, label + ": missing/unexpected input field")
                check(type(row["num_docs"]) is int and row["num_docs"] == spec["num_docs"], label + ": wrong num_docs")
                check(row["gold_position"] == spec["gold_position"], label + ": wrong gold_position")
                check(row["gold_index"] == spec["gold_index"] and
                      (row["gold_index"] is None or type(row["gold_index"]) is int), label + ": wrong gold_index")
                check(row["condition"] == spec["condition"], label + ": wrong condition")
                check(row["question"] == source["question"] and row["answers"] == source["answers"],
                      label + ": question/reference answers changed")
                check(type(row["src_row_index"]) is int and row["src_row_index"] == row_index
                      and row["src_file"] == source_file, label + ": wrong record provenance")
                ctxs = row["ctxs"]
                check(isinstance(ctxs, list) and len(ctxs) == spec["num_docs"], label + ": wrong ctxs length")
                for ctx in ctxs:
                    check(isinstance(ctx, dict), label + ": context must be object")
                    check(PROVENANCE_FIELDS.issubset(ctx), label + ": context provenance missing")
                    check(ctx["src_file"] == source_file and type(ctx["src_row_index"]) is int
                          and ctx["src_row_index"] == row_index, label + ": wrong context source file/row")
                    ctx_index = ctx["src_ctx_index"]
                    check(type(ctx_index) is int and 0 <= ctx_index < len(source["ctxs"]),
                          label + ": source context index out of range/type")
                    original = source["ctxs"][ctx_index]
                    retained = {key: value for key, value in ctx.items() if key not in PROVENANCE_FIELDS}
                    check(retained == original, label + ": document altered/truncated or metadata lost")
                    check(type(ctx.get("isgold")) is bool and type(ctx.get("hasanswer")) is bool,
                          label + ": context flags must be booleans")
                if spec["num_docs"] == 0:
                    check(ctxs == [], label + ": closed-book document leakage")
                else:
                    gold_indices = [i for i, ctx in enumerate(ctxs) if ctx["isgold"]]
                    check(gold_indices == [spec["gold_index"]], label + ": unique gold is at wrong position")
                    check([i for i, ctx in enumerate(ctxs) if ctx["hasanswer"]] == gold_indices,
                          label + ": hasanswer/isgold flags disagree")
                    gold = ctxs[spec["gold_index"]]
                    check(doc_content(gold) == doc_content(sources["10doc_start"][row_index]["ctxs"][0]),
                          label + ": gold differs from mother file")
                    if split == "full":
                        haystack = normalized_answer(gold["title"] + " " + gold["text"])
                        if not any(normalized_answer(a) and normalized_answer(a) in haystack for a in row["answers"]):
                            no_answer_in_gold.add(row["qid"])
                if spec["num_docs"] in (1, 10):
                    check([ctx["src_ctx_index"] for ctx in ctxs] == list(range(spec["num_docs"])),
                          label + ": official 10doc/oracle was reordered")
                elif spec["num_docs"] == 5:
                    mother_ctxs = sources["10doc_start"][row_index]["ctxs"]
                    expected_non_gold_indices = [i for i, ctx in enumerate(mother_ctxs) if not ctx["isgold"]][:4]
                    check([ctx["src_ctx_index"] for ctx in ctxs if not ctx["isgold"]] == expected_non_gold_indices,
                          label + ": not the first four mother-file distractors in order")
                    check(gold["src_ctx_index"] == 0, label + ": five-doc gold lost mother-file index")
                prompt = build_prompt(row)
                if spec["num_docs"] == 0:
                    expected_prompt = upstream_templates["closedbook_qa.prompt"].format(question=source["question"])
                    template_name = "closedbook_qa.prompt"
                else:
                    # Build the reference from official source text, rather than trusting output text.
                    source_docs = [source["ctxs"][ctx["src_ctx_index"]] for ctx in ctxs]
                    search_results = "\n".join("Document [{}](Title: {}) {}".format(i + 1, c["title"], c["text"])
                                               for i, c in enumerate(source_docs))
                    expected_prompt = upstream_templates["qa.prompt"].format(question=source["question"], search_results=search_results)
                    template_name = "qa.prompt"
                check(prompt == expected_prompt, label + ": prompt differs from official source/template")
                metadata_variant = copy.deepcopy(row)
                metadata_variant["answers"] = ["B_METADATA_ONLY_SENTINEL_7c5e4"]
                metadata_variant["src_file"] = "B_METADATA_ONLY_SOURCE"
                for ctx in metadata_variant["ctxs"]:
                    ctx["src_file"] = "B_METADATA_ONLY_SOURCE"
                    ctx["isgold"] = not ctx["isgold"]
                check(build_prompt(metadata_variant) == prompt, label + ": prompt depends on hidden answer/audit metadata")
                characters.append(len(prompt))
                prompt_audit.append({"split": split, "file": relative, "qid": row["qid"],
                                     "condition": spec["condition"], "num_docs": spec["num_docs"],
                                     "gold_position": spec["gold_position"], "template": template_name,
                                     "prompt_sha256": text_sha256(prompt), "prompt_chars": len(prompt),
                                     "source_text_preserved": True, "matches_official_template": True,
                                     "model_token_budget_verified": False})
                if split == "trial10" and spec["condition"] not in prompt_examples:
                    prompt_examples[spec["condition"]] = prompt
            datasets[split][spec["condition"]] = rows
            maximum = max(characters)
            longest_index = characters.index(maximum)
            input_file_summaries.append({"file": relative, "condition": spec["condition"], "split": split,
                                         "rows": len(rows), "sha256": actual_hash,
                                         "prompt_chars_min": min(characters), "prompt_chars_max": maximum,
                                         "longest_prompt_qid": rows[longest_index]["qid"]})
    for spec in CONDITIONS:
        condition = spec["condition"]
        check(datasets["trial10"][condition] == datasets["full"][condition][:TRIAL_SIZE],
              condition + ": trial records differ from full records")
    for split, rows_for_split in datasets.items():
        for num_docs, prefix in ((10, "10doc"), (5, "5doc")):
            reference = rows_for_split[prefix + "_start"]
            for condition in (prefix + "_middle", prefix + "_end"):
                for mother, other in zip(reference, rows_for_split[condition]):
                    check([doc_content(c) for c in mother["ctxs"] if not c["isgold"]]
                          == [doc_content(c) for c in other["ctxs"] if not c["isgold"]],
                          "{}:{}:{}: distractor content/order changed across positions".format(split, num_docs, other["qid"]))
    report = {
        "status": "passed", "python_version": platform.python_version(),
        "seed": SEED, "sample_size": SAMPLE_SIZE, "trial_size": TRIAL_SIZE,
        "full_records_checked": SAMPLE_SIZE * len(CONDITIONS),
        "trial_records_checked": TRIAL_SIZE * len(CONDITIONS),
        "all_source_records_audited": sum(len(rows) for rows in sources.values()),
        "assertions_passed": checks.count,
        "sample_manifest_sha256": file_sha256(data_dir / "sample_100" / "manifest.json"),
        "qid_list_sha256": file_sha256(qids_path), "trial_qid_list_sha256": file_sha256(trial_qids_path),
        "sample_mapping_sha256": file_sha256(samples_path),
        "sources": source_summary, "prompt_template_sha256": manifest["prompt_template_sha256"],
        "files": input_file_summaries,
        "checks_passed": [
            "all_official_source_rows_and_cross_file_alignment", "source_config_and_prompt_hashes",
            "seed_42_sampling_and_stable_unique_qids", "schema_types_and_condition_fields",
            "same_questions_and_reference_answers_in_all_conditions", "unique_gold_and_correct_positions",
            "unmodified_source_document_fields_and_text", "complete_file_row_ctx_provenance",
            "official_10doc_and_oracle_order_preserved", "5doc_first_four_distractors_only",
            "distractor_order_and_content_fixed_across_positions", "closedbook_no_documents",
            "oracle_same_gold_as_main_experiment", "trial_exact_prefix_of_full",
            "every_prompt_matches_official_source_and_template", "hidden_metadata_does_not_change_prompt",
        ],
        "answer_in_gold_diagnostic": {"normalization": "SQuAD-normalized substring in gold title+text; diagnostic only",
                                      "missing_qids": sorted(no_answer_in_gold), "excluded_or_replaced_samples": 0},
        "model_context_budget": {"status": "pending_member_C", "reserved_output_tokens": 300,
                                 "reason": "Requires actual model tokenizer, message wrapper and deployed max_model_len; character counts are not token counts."},
        "inference_status": "not_run; no model answers or accuracy results generated",
        "next_gate": "C one-call smoke and trial inference -> D scoring -> A review -> full inference",
    }
    return report, prompt_audit, prompt_examples


def write_reports(report_dir, report, prompt_audit, prompt_examples):
    report_dir = Path(report_dir)
    write_bytes(report_dir / "validation_report.json", json_bytes(report))
    write_bytes(report_dir / "prompt_audit.jsonl", jsonl_bytes(prompt_audit))
    for name, prompt in prompt_examples.items():
        write_bytes(report_dir / "prompt_examples" / (name + ".txt"), (prompt + "\n").encode("utf-8"))
    lines = ["# 成员 B 数据验收记录", "", "状态：**通过**（数据与 prompt 静态校验）。", "",
             "- 固定样本：100 题，seed=42；试跑为固定前 10 题。",
             "- 全量输入：800 条；试跑输入：80 条；源记录审计：10620 条。",
             "- 实际通过检查：{} 项断言。".format(report["assertions_passed"]),
             "- 所有文档完整保留，三位置干扰文档内容与顺序一致。",
             "- 每篇文档的源文件、源记录行、源 ctx 索引均验证通过。",
             "- 880 条 prompt 均与官方模板和源文本匹配，答案/审计元信息不影响 prompt。", "",
             "| 文件 | 条数 | 最短 prompt 字符数 | 最长 prompt 字符数 | 最长样本 qid |",
             "|---|---:|---:|---:|---|"]
    for item in report["files"]:
        lines.append("| `{file}` | {rows} | {prompt_chars_min} | {prompt_chars_max} | `{longest_prompt_qid}` |".format(**item))
    lines += ["", "字符数用于定位长输入，**不是 token 数**。",
              "实际 tokenizer、消息包装后的输入 token 数、输出预留 300 tokens 与部署窗口的检查待 C 完成。",
              "本记录没有模型调用、评分、U 型曲线或试跑通过结论。",
              "C 先单条调用和试跑，D 评分，A 核对通过后再运行全量。", "",
              "详见 `validation_report.json`、`prompt_audit.jsonl` 和 `../README.md`。", ""]
    write_bytes(report_dir / "validation_report.md", "\n".join(lines).encode("utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=PROJECT_ROOT / "data")
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--report-dir", type=Path, help="Defaults to DATA_DIR/checks")
    parser.add_argument("--no-write", action="store_true", help="Validate without writing audit reports")
    args = parser.parse_args()
    report_dir = args.report_dir or args.data_dir / "checks"
    try:
        report, prompt_audit, prompt_examples = validate_data(args.data_dir, args.source_root)
        if not args.no_write:
            write_reports(report_dir, report, prompt_audit, prompt_examples)
    except (DataError, OSError, KeyError, TypeError, ValueError) as error:
        if not args.no_write:
            write_bytes(report_dir / "validation_report.json", json_bytes({"status": "failed", "error": str(error)}))
            write_bytes(report_dir / "validation_report.md", ("# 成员 B 数据验收记录\n\n状态：**失败**。\n\n" + str(error) + "\n").encode("utf-8"))
        print("FAIL: {}".format(error), file=sys.stderr)
        return 1
    print("PASS: {} full + {} trial records; {} source rows; {} assertions.".format(
        report["full_records_checked"], report["trial_records_checked"],
        report["all_source_records_audited"], report["assertions_passed"]))
    print("Actual model tokenizer/context-window check: pending member C.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
