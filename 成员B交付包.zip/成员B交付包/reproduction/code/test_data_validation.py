"""Regression tests: reject experimental confounds even after file hashes are updated."""

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

from data_common import DataError, PROJECT_ROOT, file_sha256, find_source_root, json_bytes, jsonl_bytes, load_json, load_jsonl
from prepare_data import prepare
from validate_data import validate_data


class ValidationRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = PROJECT_ROOT / "data"
        cls.source_root = find_source_root()
        cls.managed_paths = [item["file"] for item in load_json(cls.original / "sample_100" / "manifest.json")["input_files"]]
        cls.managed_paths += ["sample_100/qids.txt", "sample_100/samples.jsonl", "sample_100/manifest.json",
                              "trial10/qids.txt", "trial10/README.md"]
        cls.scratch_root = (PROJECT_ROOT / ".member_b_test_tmp").resolve()
        cls.scratch_root.mkdir(exist_ok=True)

    def setUp(self):
        self.data_dir = Path(tempfile.mkdtemp(prefix="case-", dir=str(self.scratch_root))).resolve()
        for relative in self.managed_paths:
            target = self.data_dir / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.original / relative, target)

    def tearDown(self):
        # Verify containment immediately before recursively removing test-created files.
        target = self.data_dir.resolve()
        self.assertIn(self.scratch_root, target.parents)
        self.assertNotEqual(target, self.scratch_root)
        shutil.rmtree(target)

    @classmethod
    def tearDownClass(cls):
        cls.scratch_root.rmdir()  # Empty directory only; preserve it if unexpected files exist.

    def mutate_records(self, relative, mutation):
        path = self.data_dir / relative
        rows = load_jsonl(path)
        mutation(rows)
        path.write_bytes(jsonl_bytes(rows))
        manifest_path = self.data_dir / "sample_100" / "manifest.json"
        manifest = load_json(manifest_path)
        for item in manifest["input_files"]:
            if item["file"] == relative:
                item["sha256"] = file_sha256(path)
        manifest_path.write_bytes(json_bytes(manifest))

    def reject(self, fragment):
        with self.assertRaisesRegex(DataError, fragment):
            validate_data(self.data_dir, self.source_root)

    def test_truncated_document_is_rejected(self):
        self.mutate_records("10doc/首.jsonl", lambda rows: rows[0]["ctxs"][1].update(text="TRUNCATED"))
        self.reject("document altered/truncated")

    def test_changed_distractor_order_is_rejected(self):
        def swap(rows):
            ctxs = rows[0]["ctxs"]
            ctxs[0], ctxs[4] = ctxs[4], ctxs[0]
        self.mutate_records("5doc/中.jsonl", swap)
        self.reject("first four mother-file distractors in order")

    def test_wrong_gold_position_is_rejected(self):
        def swap(rows):
            ctxs = rows[0]["ctxs"]
            ctxs[4], ctxs[5] = ctxs[5], ctxs[4]
        self.mutate_records("10doc/中.jsonl", swap)
        self.reject("unique gold is at wrong position")

    def test_changed_reference_answer_is_rejected(self):
        self.mutate_records("closedbook.jsonl", lambda rows: rows[0].update(answers=["WRONG_REFERENCE"]))
        self.reject("question/reference answers changed")

    def test_duplicate_qid_is_rejected(self):
        self.mutate_records("10doc/首.jsonl", lambda rows: rows[1].update(qid=rows[0]["qid"]))
        self.reject("qid order/uniqueness")

    def test_trial_resampling_is_rejected(self):
        replacement = load_jsonl(self.data_dir / "10doc" / "首.jsonl")[10]
        self.mutate_records("trial10/10doc/首.jsonl", lambda rows: rows.__setitem__(0, replacement))
        self.reject("qid order/uniqueness")

    def test_closedbook_document_leakage_is_rejected(self):
        gold = load_jsonl(self.data_dir / "10doc" / "首.jsonl")[0]["ctxs"][0]
        self.mutate_records("closedbook.jsonl", lambda rows: rows[0].update(ctxs=[gold]))
        self.reject("wrong ctxs length")

    def test_invalid_source_context_index_is_rejected(self):
        self.mutate_records("5doc/尾.jsonl", lambda rows: rows[0]["ctxs"][0].update(src_ctx_index=999))
        self.reject("source context index out of range/type")

    def test_regeneration_is_byte_identical(self):
        before = {relative: file_sha256(self.data_dir / relative) for relative in self.managed_paths}
        summary = prepare(self.source_root, self.data_dir)
        after = {relative: file_sha256(self.data_dir / relative) for relative in self.managed_paths}
        self.assertEqual(summary["created_artifacts"], 0)
        self.assertEqual(before, after)

    def test_generator_preserves_different_existing_data(self):
        target = self.data_dir / "5doc" / "首.jsonl"
        target.write_bytes(b'{"existing_user_data":true}\n')
        before = {relative: file_sha256(self.data_dir / relative) for relative in self.managed_paths}
        with self.assertRaisesRegex(DataError, "Existing artifact differs"):
            prepare(self.source_root, self.data_dir)
        after = {relative: file_sha256(self.data_dir / relative) for relative in self.managed_paths}
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main(verbosity=2)
