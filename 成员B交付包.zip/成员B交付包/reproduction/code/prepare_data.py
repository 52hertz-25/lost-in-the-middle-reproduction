"""Produce member B's frozen 100-question inputs and 10-question trial subset."""

import argparse
import copy
import hashlib
import random
import sys
from pathlib import Path

from data_common import (
    CONDITIONS, DataError, POPULATION_SIZE, PROJECT_ROOT, SAMPLE_SIZE,
    SAMPLING_ALGORITHM, SEED, SOURCE_FILES, TRIAL_SIZE, file_sha256,
    find_source_root, json_bytes, jsonl_bytes, load_and_audit_sources,
    qid_for, relative_path, require, template_snapshot, write_bytes,
)


def source_context(ctx, file_name, row_index, ctx_index):
    result = copy.deepcopy(ctx)
    result.update(src_file=file_name, src_row_index=row_index, src_ctx_index=ctx_index)
    return result


def make_record(spec, row_index, sources):
    row = sources[spec["source"]][row_index]
    file_name = SOURCE_FILES[spec["source"]]
    original_ctxs = [(i, ctx) for i, ctx in enumerate(row["ctxs"])]
    if spec["num_docs"] == 0:
        selected = []
    elif spec["num_docs"] == 5:
        gold = next(pair for pair in original_ctxs if pair[1]["isgold"])
        selected = [pair for pair in original_ctxs if not pair[1]["isgold"]][:4]
        selected.insert(spec["gold_index"], gold)
    else:
        # 10-document inputs and oracle are extracted without reordering.
        selected = original_ctxs
    return {
        "qid": qid_for(row_index), "question": row["question"],
        "answers": copy.deepcopy(row["answers"]),
        "num_docs": spec["num_docs"], "gold_position": spec["gold_position"],
        "gold_index": spec["gold_index"], "condition": spec["condition"],
        "src_file": file_name, "src_row_index": row_index,
        "ctxs": [source_context(ctx, file_name, row_index, index) for index, ctx in selected],
    }


def prepare(source_root, data_dir):
    sources, source_summary = load_and_audit_sources(source_root)
    prompt_hashes = template_snapshot(source_root)
    indices = random.Random(SEED).sample(range(POPULATION_SIZE), SAMPLE_SIZE)
    qids = [qid_for(i) for i in indices]
    trial_qids = qids[:TRIAL_SIZE]
    artifacts = {}
    inputs = []
    for spec in CONDITIONS:
        rows = [make_record(spec, i, sources) for i in indices]
        for split, relative, selected in (("full", spec["file"], rows),
                                          ("trial10", "trial10/" + spec["file"], rows[:TRIAL_SIZE])):
            content = jsonl_bytes(selected)
            artifacts[relative] = content
            inputs.append({"file": relative, "split": split, "condition": spec["condition"],
                           "rows": len(selected), "num_docs": spec["num_docs"],
                           "gold_position": spec["gold_position"], "gold_index": spec["gold_index"],
                           "sha256": hashlib.sha256(content).hexdigest()})
    samples = [{"qid": qid_for(i), "src_file": SOURCE_FILES["10doc_start"],
                "src_row_index": i, "question": sources["10doc_start"][i]["question"],
                "answers": sources["10doc_start"][i]["answers"]} for i in indices]
    artifacts["sample_100/qids.txt"] = ("\n".join(qids) + "\n").encode("utf-8")
    artifacts["sample_100/samples.jsonl"] = jsonl_bytes(samples)
    artifacts["trial10/qids.txt"] = ("\n".join(trial_qids) + "\n").encode("utf-8")
    manifest = {
        "schema_version": 1, "seed": SEED, "population_size": POPULATION_SIZE,
        "sample_size": SAMPLE_SIZE, "trial_size": TRIAL_SIZE,
        "sampling_algorithm": SAMPLING_ALGORITHM,
        "source_root_relative_to_project": relative_path(source_root),
        "qid_scheme": "nq-open-10-{src_row_index:05d}; source row and ctx indices are zero-based",
        "selected_source_row_indices": indices,
        "trial_qids": trial_qids,
        "sources": source_summary,
        "config_sha256": file_sha256(PROJECT_ROOT / "configs" / "experiment_config.md"),
        "prompt_template_sha256": prompt_hashes,
        "baseline_field_convention": {
            "closedbook": {"num_docs": 0, "gold_position": None, "gold_index": None, "ctxs": []},
            "oracle": {"num_docs": 1, "gold_position": None, "gold_index": 0},
            "discriminator": "condition; do not treat baseline gold_position=null as a location condition",
        },
        "input_files": inputs,
        "model_execution_status": "not_run_by_member_B",
        "full_run_gate": "C trial -> D scoring -> A review before running full model inference",
    }
    artifacts["sample_100/manifest.json"] = json_bytes(manifest)
    artifacts["trial10/README.md"] = (
        "# 固定 10 题试跑包\n\n"
        "本目录是 `../sample_100/qids.txt` 的前 10 题，八套输入与全量文件逐条一致。\n\n"
        "1. C 先读取 `10doc/首.jsonl` 的第一条测试一次调用。\n"
        "2. 初次位置试跑：10doc 的首/中/尾各 10 题，共 30 次/模型。\n"
        "3. 完整试跑：六个位置条件与 closedbook、oracle，共 80 次/模型。\n"
        "4. D 评分、A 核对通过后，再运行父目录的 100 题全量输入。\n\n"
        "本目录只有实验输入，没有模型输出或试跑通过记录。字段与命令见父目录 README。\n"
    ).encode("utf-8")
    # Preflight the entire output set: never silently replace different existing data.
    for relative, content in artifacts.items():
        target = data_dir / relative
        require(not target.exists() or target.read_bytes() == content,
                "Existing artifact differs: {}. Preserve it and choose a new --data-dir; do not resample silently.".format(target))
    written = 0
    for relative, content in artifacts.items():
        target = data_dir / relative
        if not target.exists():
            write_bytes(target, content)
            written += 1
    return {"source_rows_per_file": POPULATION_SIZE, "sample_size": SAMPLE_SIZE,
            "trial_size": TRIAL_SIZE, "full_records": SAMPLE_SIZE * len(CONDITIONS),
            "trial_records": TRIAL_SIZE * len(CONDITIONS), "created_artifacts": written,
            "managed_artifacts": len(artifacts), "source_root": str(source_root), "data_dir": str(data_dir)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, help="Official repository directory containing qa_data/")
    parser.add_argument("--data-dir", type=Path, default=PROJECT_ROOT / "data")
    args = parser.parse_args()
    try:
        summary = prepare(find_source_root(args.source_root), args.data_dir.resolve())
    except (DataError, OSError, KeyError, StopIteration) as error:
        print("ERROR: {}".format(error), file=sys.stderr)
        return 1
    print("Prepared: {} full + {} trial records; {} new / {} managed artifacts.".format(
        summary["full_records"], summary["trial_records"], summary["created_artifacts"], summary["managed_artifacts"]))
    print("Next: python code/validate_data.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
