# 成员 B 数据工具

已实现固定抽样、八种条件输入生成、10 题试跑子集、独立数据校验及官方 prompt 渲染。仅用 Python 标准库，兼容 Python 3.9+，不需要 GPU、pip 安装或模型下载。

## 文件

| 文件 | 用途 |
|---|---|
| `prepare_data.py` | 审计源数据，seed=42 抽 100 题，生成 800 条全量和 80 条试跑输入 |
| `validate_data.py` | 对照官方源记录逐条校验，输出 JSON/Markdown 验收记录及 prompt 审计 |
| `prompting.py` | 渲染官方模板；供 C 导入 `build_prompt(record)` 或用命令行预览 |
| `data_common.py` | 固定条件、文件读写、源数据审计等共享工具 |
| `test_data_validation.py` | 数据损坏、变量混入、闭书泄漏及重复生成的回归检查 |

## 本机运行

在 PowerShell 中进入 `reproduction/`，使用 Python 3.9+ 运行：

```powershell
python -B .\code\prepare_data.py
python -B .\code\validate_data.py
python -B .\code\test_data_validation.py
```

其他机器有 Python 3.9+ 时，执行：

```bash
python code/prepare_data.py
python code/validate_data.py
python code/test_data_validation.py
```

生成/校验命令的默认输入、输出路径以脚本位置为基准，不依赖当前工作目录。显式传入的相对路径以及 prompt 预览命令的输入/输出路径相对于当前工作目录。

## 迁移到服务器

默认查找 `reproduction/official_repo/lost-in-the-middle-main/`，其次查找当前工作区的 `lost-in-the-middle-main/lost-in-the-middle-main/`。其他目录可显式指定：

```bash
python code/prepare_data.py --source-root /path/to/lost-in-the-middle-main
python code/validate_data.py --source-root /path/to/lost-in-the-middle-main
```

`--source-root` 指向包含 `qa_data/` 和 `src/lost_in_the_middle/prompts/` 的官方仓库根目录。

相同输入重复生成不会改写文件。已有数据与固定结果不一致时，生成器会退出并保留已有文件；请先查明原因，必要时用 `--data-dir` 指定新的输出目录。不能为得到更好的结果反复抽样。

仅检查、不改写审计记录：

```bash
python code/validate_data.py --no-write
```

成功返回退出码 0；检测到问题返回非 0。默认校验会生成 `data/checks/validation_report.json`，失败时明确写 `status=failed`，避免把之前的通过记录当成最新结果。

## 给 C 的 prompt 接口

从 `code/` 目录导入：

```python
from prompting import build_prompt

prompt = build_prompt(record)
messages = [{"role": "user", "content": prompt}]
```

这仅给出配置所规定的用户消息。C 应按各模型官方推理接口处理其消息包装，并记录实际 tokenizer、包装方式、版本和窗口上限。

首条调用的 prompt 预览：

```powershell
python -B .\code\prompting.py --input '.\data\trial10\10doc\首.jsonl' --limit 1 --output '.\data\checks\smoke_prompt.jsonl'
```

输出包含 qid、condition、完整 prompt、prompt SHA256 和仅含 user 的 messages，不包含答案和审计元信息。该文件是预览，不是推理日志。C 的正式日志仍需保留原始输入字段并追加模型输出、版本、usage、耗时等。

不做推理、不产生评分、不伪造 token 数。实际输入 token 数必须由 C 使用部署 tokenizer 和消息包装测量，并检查输入 token 数 + 300 ≤ 实际上下文窗口，禁止自动截断。

## 回归检查的含义

测试在工作区内创建独立临时副本，修改后还会更新对应文件的 SHA256，确保校验器确实检查语义而非仅检查哈希。覆盖正文截断、干扰文档重排、gold 错位、答案更改、qid 重复、试跑换题、闭书文档泄漏和来源索引错误；另检查重复生成字节一致，以及生成器保留不同的已有文件。

每个临时副本删除前都校验其路径位于指定测试目录内。正式数据、配置、官方仓库不受测试修改。
