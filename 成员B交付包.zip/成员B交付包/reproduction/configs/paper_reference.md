# 论文速查与原文定位（paper_reference.md）

> 用途：A 写报告引用、全组对齐认知、答辩准备。所有内容基于论文原文（`_source/2024.tacl-1.9.pdf`，TACL 2024, pp.157–173）与官方仓库核对。

---

## 1. 文献信息（报告参考文献直接抄这段）

> Nelson F. Liu, Kevin Lin, John Hewitt, Ashwin Paranjape, Michele Bevilacqua, Fabio Petroni, and Percy Liang. 2024. **Lost in the Middle: How Language Models Use Long Contexts.** *Transactions of the Association for Computational Linguistics*, 12:157–173. https://doi.org/10.1162/tacl_a_00638 （arXiv:2307.03172）

## 2. 核心结论速览（5 条，报告"论文与问题"用）

1. **U 型曲线**：相关信息在输入上下文开头（首因偏置 primacy bias）或结尾（近因偏置 recency bias）时性能最高；在中间时显著下降（Lost in the Middle）。
2. **不是推理问题**：连纯提取任务（键-值检索，UUID 无语义）都会"迷失在中间"，说明是基础的信息读取/利用缺陷。
3. **扩展上下文 ≠ 更会用上下文**：输入长度在两者窗口内时，GPT-3.5-Turbo 与 16K 版曲线几乎重合。
4. **三个消融**：① encoder-decoder 在训练长度内鲁棒、超长后仍 U 型；② 查询感知上下文（query 前后各放一次）对 KV 检索近乎满分，对多文档 QA 几乎无效；③ 基座模型（未指令微调）同样 U 型 → 不是指令微调造成的。
5. **RAG 启示**：retriever-reader 案例中 reader 准确率远早于 recall 饱和；50 篇 vs 20 篇只提升 ~1–1.5%；应重排（把高价值文档放前）或截断。

## 3. 复现范围 → 原文定位表（报告"定位到具体小节/图表"就用这张表）

| 我们的实验内容 | 原文对应 | 页码 |
|---|---|---|
| 多文档 QA 任务定义 | §2（2.1 Experimental Setup） | p.159–160 |
| 任务示例（输入/期望输出） | Figure 2（3 篇示例）；Figure 3（位置变换）；Figure 4（长度变换） | p.160 |
| 数据集与构造 | §2.1：NaturalQuestions-Open，2655 条（long answer 为段落）；干扰文档=Contriever（MS-MARCO 微调）检索；段落≤100 token；干扰文档按相关度降序 | p.159 |
| 评估指标 | §2.1：accuracy＝任一 NQ 参考答案是否出现在输出中 | p.160 |
| 模型与解码 | §2.2：greedy decoding；GPT-3.5-Turbo/16K（0613 版）、Claude-1.3/100K、MPT-30B-Instruct（8K）、LongChat-13B-16K | p.160–161 |
| 闭书/oracle 基线 | Table 1 | p.161 |
| 位置-准确率主结果 | Figure 5（10/20/30 篇 ≈ 2K/4K/6K tokens） | p.161 |
| "中间低于闭书"关键证据 | §2.3：GPT-3.5-Turbo 中间位置低于 closed-book 56.1%；20/30 篇最差位置性能下降超 20% | p.161–162 |
| 扩展窗口结论 | §2.3：10/20 篇下 4K 与 16K 版曲线几乎重合 | p.162 |
| KV 检索任务 | §3（3.1 Setup、3.2 Results）；Figure 6（示例）；Figure 7（75/140/300 对 ≈ 4K/8K/16K tokens，每档 500 例） | p.162–163 |
| 架构消融（encoder-decoder） | §4.1；Figure 8（Flan-UL2 训练长度内 best-worst 差 1.9%） | p.163–164 |
| 查询感知上下文消融 | §4.2；Figure 9（QA 几乎无效）；KV 版本近乎满分（GPT-3.5-16K 300 对满分；无该消融最差 45.6%） | p.164 |
| 指令微调消融 | §4.3；Figure 10（MPT-30B vs Instruct 均 U 型；差幅 10%→4%） | p.165 |
| 模型规模（附录） | Appendix E：Llama-2 7B 仅近因偏置；13B/70B U 型 | p.165–166 |
| RAG 案例研究 | §5；Figure 11（reader 饱和早于 recall；>20 篇提升 ~1–1.5%） | p.166 |
| 随机干扰文档 | Appendix B（附录）；随机文档仍 U 型 | p.159 脚注 3 |
| 随机顺序提示 | Appendix C（附录）；"results are ordered randomly" 仍 U 型 | p.160 脚注 4 |
| GPT-4 子集实验 | Appendix D | p.161 脚注 6 |

## 4. 关键数字表（报告对照用；来源：Table 1 / §2.3 / EXPERIMENTS.md）

### 4.1 论文 Table 1：闭书 / Oracle 准确率（多文档 QA，全 2655 条）
| 模型 | Closed-Book | Oracle |
|---|---|---|
| LongChat-13B (16K) | 35.0% | 83.4% |
| MPT-30B-Instruct | 31.5% | 81.9% |
| GPT-3.5-Turbo | 56.1% | 88.3% |
| GPT-3.5-Turbo (16K) | 56.0% | 88.6% |
| Claude-1.3 | 48.3% | 76.1% |
| Claude-1.3 (100K) | 48.2% | 76.4% |

### 4.2 官方仓库 EXPERIMENTS.md 基线（20 篇文档，gold_index=0/4/9/14/19，最佳子串 EM 口径）
| 模型 | oracle | closedbook | 20doc:0 | 20doc:4 | 20doc:9 | 20doc:14 | 20doc:19 |
|---|---|---|---|---|---|---|---|
| mpt-30b-instruct | 81.66 | 31.68 | 53.67 | 51.75 | 52.17 | 52.66 | 56.23 |
| longchat-13b-16k | 82.64 | 34.99 | 68.59 | 57.40 | 55.33 | 52.50 | 55.03 |
| llama-2-70b-chat-hf | 84.67 | 35.29 | 56.77 | 53.32 | 54.08 | 59.66 | 69.49 |

> 注意：20 篇的"中间"≈ gold_index 9/14；可见长上下文中间位置明显低于首尾 → 本组 10 篇用 0/4/9 与此同构。
> KV 检索官方基线（140 对）：mpt gold 0/34/69/104/139 = 1.0/0.936/0.886/0.804/0.962；longchat = 0.37/0.382/0.354/0.656/0.886。

## 5. 任务与设置细节（写作/答辩引用）

**多文档 QA**：
- 输入：1 个问题 + k 篇文档（恰 1 篇含答案，k−1 篇干扰）；干扰文档按相关度**降序**排列（默认"搜索结果"先验）；
- 数据：NaturalQuestions-Open 中 long answer 为段落的 **2655** 条（已核验官方数据每文件 2655 行）；
- 文档：维基段落，**每个 ≤100 token**；答案文档= NQ 标注段落；干扰文档= Contriever（MS-MARCO 微调）检索的不含答案片段；
- 长度：10/20/30 篇 ≈ 2K/4K/6K tokens；位置：遍历全部位置；
- 指标：**accuracy**＝任一参考答案出现在输出中（代码实现：首行 + SQuAD 归一化 + 子串，见 §7）；
- 解码：**greedy**（temperature=0）。

**KV 检索**：
- 输入：字符串化的 JSON，k 对 UUID 键值（键值唯一、无语义）+ 目标 key；
- 长度：75/140/300 对（≈4K/8K/16K tokens），各 500 例；位置：目标 key 在 JSON 中的位置；
- 指标：输出是否包含正确 value（精确匹配）。

**消融**：
- 架构：Flan-T5-XXL（训练 512）、Flan-UL2（2048）；训练长度内鲁棒，超长 U 型；
- 查询感知：query 放文档前+后；KV 近乎满分，QA 几乎无效；
- 指令微调：MPT-30B vs Instruct 均 U 型；SFT/RLHF（Llama-2）只轻微缓解，不消除。

## 6. 官方仓库使用指南（A 与 C 必读）

位置：`official_repo/lost-in-the-middle-main/`

| 内容 | 路径 |
|---|---|
| 数据：QA 10/20/30 篇 + oracle（各 2655 条） | `qa_data/` |
| 数据：KV 75/140/300 对（各 500 条） | `kv_retrieval_data/` |
| 评估脚本（QA/KV） | `scripts/evaluate_qa_responses.py`、`scripts/evaluate_kv_responses.py` |
| 生成预测脚本（本地模型） | `scripts/get_qa_responses_from_{mpt,longchat,llama_2}.py`、`get_kv_responses_from_*.py` |
| prompt 模板（6 个 .prompt） | `src/lost_in_the_middle/prompts/`（已复制到 `configs/prompts/`） |
| prompt/文档拼接逻辑 | `src/lost_in_the_middle/prompting.py` |
| 评分指标 | `src/lost_in_the_middle/metrics.py`（best_subspan_em） |
| 复现命令与基线数字 | `EXPERIMENTS.md`、`README.md` |
| 环境 | `requirements.txt`、`pyproject.toml`（conda python 3.9 + `pip install -e .`） |

关键命令示例（作者用 A100 跑本地模型；本组走 API 时只复用**数据 + prompt + 评分逻辑**）：
```bash
# 作者：mpt-30b-instruct 预测 + 评分
python scripts/get_qa_responses_from_mpt.py --input-path qa_data/nq-open-oracle.jsonl.gz \
    --model mosaicml/mpt-30b-instruct --max-new-tokens 100 --output-path preds.jsonl.gz
python scripts/evaluate_qa_responses.py --input-path preds.jsonl.gz --output-path scored.jsonl.gz
```

## 7. 评分口径的原文依据（D 实现前必读，防止口径纠纷）

- 论文文字（§2.1）：accuracy = "whether any of the correct answers ... appear in the predicted output"；
- 官方代码（evaluate_qa_responses.py）：取 `model_answer.split("\n")[0].strip()`（**只评第一行**，注释：防模型复读输入上下文刷分）；
- 官方代码（metrics.py）：SQuAD `normalize_answer`（小写/去标点/去 a-an-the/折叠空白）后**子串匹配**；
- 结论：**本组主指标按官方代码口径**（首行 + 归一化 + 子串），在报告设置差异表中注明与论文文字的差别。

## 8. 本组与原论文差异表（浓缩版，写入报告）

| 维度 | 原文 | 本组 |
|---|---|---|
| 样本 | 2655 条全量 | 100 条（seed=42 固定） |
| 文档数 | 10/20/30 | 5/10 |
| 位置 | 遍历全部 | 首/中/尾 3 点 |
| 任务 | QA + KV | 仅 QA（KV 可选拓展） |
| 模型 | 6 个（已下线） | 1 个现代模型（见决策记录） |
| 消融 | 3 组 | 默认不做（可选 query-aware） |
| 指标 | accuracy | 答案包含率（官方代码口径，更严格） |
| 复现类型 | — | 缩规模复现 |

## 9. 常见坑（A 传达给全组）

1. **勿用新模型数值硬比原文**：模型世代不同，比趋势不比数值；
2. **勿改 prompt**：连标点都照抄 `configs/prompts/`；
3. **勿改解码**：temperature=0；采样会让结果不可复现；
4. **评分取首行**：否则模型复读文档会"刷"出高分假象；
5. **10 篇直接用官方 gold_at_0/4/9**：不要自己重排，官方文件即"证据在第 1/5/10 位"；
6. **5 篇派生保追溯**：记录 src_file + src_ctx_index；
7. **作者代码只读参考**：本组 API 路线只复用数据/prompt/评分，不跑作者 A100 脚本。

## 10. 引用与来源清单

- 论文 PDF：`_source/2024.tacl-1.9.pdf`（DOI 见 §1）
- 官方仓库：`official_repo/lost-in-the-middle-main/`（github.com/nelsonliu-ai/lost-in-the-middle）
- 课程说明：`_source/课程说明.pdf`（P35 登记、评分标准、时间安排）
- 分工文档：`_source/分工.docx`
