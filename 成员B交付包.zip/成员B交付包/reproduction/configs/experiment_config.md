# 实验配置总纲（experiment_config.md）

> 本文件是**组内实验契约**：B（数据）、C（调用）、D（评分）全部以本文件为准执行；任何修改须 A 确认并在此登记。
> 
> 复现类型标签：**缩规模复现**（减少样本/文档数，保留比较逻辑；数值不与原文硬对齐）。

---

## 1. 研究问题与假设

**研究问题**：在多文档问答中，把唯一含答案的证据文档放在上下文的不同位置（首/中/尾），模型的回答准确率是否显著变化？是否复现论文的"Lost in the Middle（U 型曲线）"现象？

**可证伪假设 H**：在 5 篇与 10 篇两种文档数条件下，证据文档位于**中间**位置时的准确率，显著低于位于**首、尾**时的准确率（H1：中<首；H2：中<尾）。
**辅助观察**：① 10 篇条件下中间位置的准确率与 closed-book 基线（无文档）对比——论文中 GPT-3.5-Turbo 中间位置低于 closed-book（56.1%），观察本组模型是否类似（不强求复现）；② oracle 基线给出"无干扰文档时的性能上限"，用于量化干扰文档与位置造成的损失（与论文 Table 1 对照）。

---

## 2. 控制变量（两个，其余全部固定）

| 变量 | 取值 | 说明 |
|---|---|---|
| 文档总数 `num_docs` | {5, 10} | 10 篇对应论文 Figure 5 左图（~2K tokens）的变体；5 篇为缩规模附加条件 |
| 证据文档位置 `gold_position` | {首, 中, 尾} | 见 §3 定义 |

**单变量原则**：
- 同一 `(num_docs, gold_position)` 组合，除证据文档位置外，**所有文档内容、其余文档的相对顺序完全一致**；
- 两个变量的所有组合共用**同一批 100 个问题**（固定样本集，见 §5）；
- 除这两个变量外，模型、prompt、解码参数、评分口径一律不变（见 §4、§6、§7）。

---

## 3. 位置定义

### 3.1 10 篇文档条件（直接用官方文件）
| 位置 | 证据在第几位（1-based） | 证据在 ctxs 的 index（0-based） | 官方数据文件（各 2655 条） |
|---|---|---|---|
| 首 | 第 1 位 | 0 | `qa_data/10_total_documents/nq-open-10_total_documents_gold_at_0.jsonl.gz` |
| 中 | 第 5 位 | 4 | `qa_data/10_total_documents/nq-open-10_total_documents_gold_at_4.jsonl.gz` |
| 尾 | 第 10 位 | 9 | `qa_data/10_total_documents/nq-open-10_total_documents_gold_at_9.jsonl.gz` |

> 官方文件就是"证据在第 0/4/9 位"的成品，位置定义与论文实验一致（论文 10 篇条件也是这些位置）。**B 无需重排 10 篇数据**，直接从官方文件抽 100 题。

### 3.2 5 篇文档条件（从 10 篇官方文件派生，B 负责）
规则：取同一问题的 10 篇 ctxs 中 **gold 文档 + 前 4 篇干扰文档**（按官方文件中的 ctx 顺序取前 4 个非 gold 文档），组成 5 篇；再把 gold 放到指定位置：
| 位置 | 证据在第几位（1-based） | 证据在 5 篇列表的 index（0-based） |
|---|---|---|
| 首 | 第 1 位 | 0 |
| 中 | 第 3 位 | 2 |
| 尾 | 第 5 位 | 4 |

派生要求：
1. 5 篇三套输入中，**4 篇干扰文档的内容与相对顺序完全一致**，仅 gold 位置不同；
2. 保留"来源可追溯"：每条 ctx 记录 `src_file`（来源官方文件名）与 `src_ctx_index`（在官方文件 ctxs 中的序号）；官方位置文件 ctxs 只含 `title/text/hasanswer/isgold` 字段（无 id），追溯用 `src_file + src_ctx_index`；
3. 输出到 `data/5doc/{首,中,尾}.jsonl`。

---

## 4. 固定不变参数（C 直接用）

| 参数 | 值 | 出处 |
|---|---|---|
| 模型 | **3 个主模型 + 1 备选（见 §13 决策记录，每个模型写死版本/快照，禁止中途换）**：MPT-30B-Instruct、LongChat-13B-16K、Qwen2.5-14B-Instruct；备选 GLM-4-Flash | `docs/模型选型方案.md` |
| 部署方式 | **服务器 GPU**：可满足三模型；开源模型建议 4-bit 量化；作者脚本面向 A100，需 C 适配或改用 vLLM/Ollama（具体卡数/显存由 C 确认后登记 §13） | 决策记录表 |
| 解码 | greedy：`temperature=0`，`top_p=1`（或不传采样参数） | 论文 §2.2 "We use greedy decoding" |
| `max_tokens` | **300**（输出上限；论文脚本用 100，300 更保险，若模型超长截断则评分只取首行不受影响） | 官方脚本 `--max-new-tokens 100` |
| 系统角色 | 无 system prompt，仅用户消息（与论文一致：单段 prompt） | 论文 Figure 2 |
| Prompt 模板 | `configs/prompts/qa.prompt`（多文档）；`configs/prompts/closedbook_qa.prompt`（闭书） | 官方仓库原文件 |
| 文档拼接格式 | `Document [{i+1}](Title: {title}) {text}`，文档之间换行连接，整体替换 `{search_results}` | 官方 `prompting.py` |
| 样本集 | 固定 100 题（§5），三位置 × 两文档数共用 | 分工文档 |
| 随机种子 | 抽取样本用固定 seed（建议 42），记录在案 | — |

---

## 5. 数据与样本

### 5.1 数据来源（官方仓库，已解压到 `official_repo/lost-in-the-middle-main/`）
- 多文档 QA：`qa_data/10_total_documents/*.jsonl.gz`（各 2655 条）、`qa_data/20_total_documents/`（2655）、`qa_data/30_total_documents/`（2655）、`qa_data/nq-open-oracle.jsonl.gz`（2655，oracle 用）；
- 记录格式：`{question, answers[], ctxs[{title, text, hasanswer, isgold}], nq_annotated_gold{...}}`；
- 每文件行数已核验：2655 行（2026-10-02）。

### 5.2 100 题固定样本（B 执行，A 确认）
1. 以官方 10 篇 `gold_at_0` 文件为母本（2655 条）；
2. **固定 seed=42** 随机抽 100 条，输出 `data/sample_100/qids.txt`（或 jsonl），全组以此为准；
3. 筛选规则（可选，建议执行）：排除 `answers` 为空或含明显非常规答案的样本？——**保持简单：直接随机 100 条即可**，不要过度筛选以免引入主观性；若试跑发现大量异常（如答案不在任何文档中），再补充规则并记录；
4. 同一 qid 在 10 篇三位置、5 篇三位置、closed-book、oracle 中必须对应同一问题与同一参考答案；
5. 5 篇样本从 10 篇样本（同一 100 题）派生（§3.2）。

### 5.3 基线数据
- **closed-book**：只用 `question`（+`answers` 供评分），不给文档 → 每模型 100 次调用；
- **oracle**：官方 `nq-open-oracle.jsonl.gz` 中抽同一 100 题 → 每模型 100 次调用。论文 Table 1 有 6 模型 oracle 数值可对照（如 GPT-3.5 88.3%），本组结果与之做量级对照。
- oracle 数据说明：`nq-open-oracle.jsonl.gz` 每行 `ctxs` 仅 1 篇（即证据文档），B 直接抽与主实验相同的 100 个 qid，输出 `data/oracle.jsonl`。

---

## 6. Prompt 模板（来自官方仓库）

### 6.1 多文档问答 `qa.prompt`
```
Write a high-quality answer for the given question using only the provided search results (some of which might be irrelevant).

{search_results}

Question: {question}
Answer:
```
其中 `{search_results}` = 文档列表，每行 `Document [i](Title: 标题) 正文`。

### 6.2 闭书 `closedbook_qa.prompt`
```
Question: {question}
Answer:
```

### 6.3 备用模板（本次不做，若做消融/拓展时启用）
- `qa_with_query_aware_contextualization.prompt`（问题放文档前后各一次）；
- `qa_ordered_randomly.prompt`（提示"results are ordered randomly"）；
- KV 检索模板两个（`kv_retrieval.prompt`、`kv_retrieval_with_query_aware_contextualization.prompt`）——本次缩规模**不做 KV 任务**，如需拓展再启用。

---

## 7. 评价指标（D 实现，口径与官方代码一致）

### 7.1 主指标：答案包含率（accuracy，论文口径）
按官方 `evaluate_qa_responses.py + metrics.best_subspan_em` 实现，步骤：
1. 取模型输出 `model_answer` 的**第一行**（`split("\n")[0]`）并 strip（防模型复读上下文刷分，官方代码注释明示）；
2. SQuAD 归一化 `normalize_answer`：小写 → 去标点 → 去 a/an/the → 折叠空白；
3. 任一参考答案归一化后若为归一化输出的**子串** → 该题 1 分，否则 0 分；
4. 汇总：`准确率 = 得分题数 / 总题数`。

> 论文文字口径是"任一参考答案是否出现在输出中"；官方代码加了"首行截断 + SQuAD 归一化"。我们**以官方代码口径为准**（更严格、可复现），并在报告设置差异表中说明这一细节。

### 7.2 辅助指标（可选，写进结果表）
- 精确匹配 EM（归一化后完全相等）；
- F1（字符级，SQuAD 口径）。

### 7.3 每题必记录（课程要求"逐题输出"）
`qid, question, answers, gold_position, num_docs, model, prompt（或 prompt 指纹）, model_answer, first_line, score, usage_tokens(输入/输出), latency_s, config_snapshot, timestamp`

---

## 8. 实验矩阵与调用预算

| 组 | 样本 | 条件 | 调用数（每模型） |
|---|---|---|---|
| 主实验 | 100 | 10 篇 × {首,中,尾} | 300 |
| 主实验 | 100 | 5 篇 × {首,中,尾} | 300 |
| 基线 closed-book | 100 | 无文档 | 100 |
| 基线 oracle | 100 | 仅证据文档 | 100 |
| **单模型小计** | | | **800** |
| **3 个主模型合计** | | | **2400** |

试跑另计（每模型）：10 题 ×（3 位置 × 2 文档数 + closed-book + oracle）= 80 次。
单次输入规模估计：10 篇 ≈ 2500–4500 tokens；5 篇 ≈ 1500–2500；输出 ≤300。

⚠️ **3 个模型 × 800 次总量不小，先跑试跑再定全量策略**：
- 本地开源模型无 token 费，但有显存/时间成本（30B 与 13B 推理速度差异大），先实测单次耗时；
- 若时间/算力不足，降级方案（须登记 §13）：**1 个模型跑全量（建议 Qwen2.5-14B），其余 2 个模型只跑 10 篇三位置 + oracle**（每模型 400 次）；或全员只跑试跑位置抽样。

---

## 9. 目录结构与结果组织（全组遵守）

```
data/
├── sample_100/          # 固定 100 题清单（B）
├── 10doc/{首,中,尾}.jsonl   # 10 篇三位置输入（B，直接从官方文件抽取）
├── 5doc/{首,中,尾}.jsonl    # 5 篇三位置输入（B，派生）
├── closedbook.jsonl    # 闭书输入
├── oracle.jsonl        # oracle 输入
└── README.md           # B 写数据说明
results/
├── raw/                # C 输出：每条件一个 jsonl（原始输出+元信息）
├── scored/             # D 评分后 jsonl（加 score 字段）
├── tables/             # 准确率汇总表 csv
├── figures/            # U 型曲线图等
├── logs/               # 运行日志
└── cases/              # ≥10 个案例分析
configs/                # 本文件 + paper_reference.md + prompts/（只读契约）
code/                   # B/C/D 代码
```

---

## 10. 数据接口规范（B 产出 → C 消费 → D 评分）

### 10.1 输入 jsonl（B 产出，C 读取）每条：
```json
{
  "qid": "nq-open-10-00042",
  "question": "...",
  "answers": ["..."],
  "num_docs": 10,
  "gold_position": "首|中|尾",
  "gold_index": 0,
  "ctxs": [
    {"title": "...", "text": "...", "isgold": false, "src_file": "...", "src_ctx_index": 3}
  ]
}
```
### 10.2 输出 jsonl（C 产出，D 读取）每条 = 输入字段 + ：
```json
{
  "model": "mpt-30b-instruct",
  "model_version": "mosaicml/mpt-30b-instruct（快照/加载日期）",
  "prompt": "完整 prompt 文本",
  "model_answer": "模型完整输出",
  "usage": {"prompt_tokens": 3210, "completion_tokens": 42, "total_tokens": 3252},
  "latency_s": 12.3,
  "config_snapshot": "experiment_config.md v2 摘要",
  "timestamp": "2026-10-05T10:00:00+08:00"
}
```

---

## 11. 复现成功判据（最后把关，A）

| 判据 | 预期 | 不达标时的处理 |
|---|---|---|
| 10 篇：中 < 首 且 中 < 尾 | 明显差距（建议 ≥5 个百分点视为明显，小样本波动允许放宽） | 先查数据位置构造与评分；仍无则如实报告并分析 |
| 5 篇：同样 U 型趋势 | 趋势存在（幅度可小于 10 篇） | 同上 |
| closed-book 对照 | 记录并对比；论文现象"中间<闭书"不要求复现 | 报告解释（新模型参数记忆更强/更会用上下文） |
| oracle 对照 | oracle 应明显高于主实验中间位置（接近性能上限），与论文 Table 1 量级对照 | 若 oracle 也低，先查数据/prompt/评分，再下结论 |
| 与论文 Figure 5 趋势对照 | 形状一致（U），数值不要求一致 | 差异写入"设置差异表" |

---

## 12. 与原论文设置差异表（报告必写，A）

| 维度 | 原论文 | 本组 | 影响 |
|---|---|---|---|
| 复现类型 | — | 缩规模复现 | 数值不硬对齐，看趋势 |
| 样本量 | 2655 | 100（固定 seed=42） | 准确率方差变大，报告波动 |
| 文档数 | 10 / 20 / 30 | 5 / 10 | 不跑 20/30（论文主图 20 篇留作可选项） |
| 位置 | 遍历全部位置 | 仅首/中/尾 | 曲线只有 3 个点，形状可辨但分辨率低 |
| 任务 | 多文档 QA + KV 检索 | 仅多文档 QA | KV 留作拓展 |
| 模型 | 6 个（GPT-3.5/Claude/MPT/LongChat，均已下线） | 3 个开源模型 + 1 备选 API（见决策记录） | 结果只对照趋势，不硬比数值 |
| 指标 | accuracy（答案出现） | 答案包含率（官方代码口径：首行+SQuAD 归一化） | 更严格，报告说明 |
| 基线 | closed-book + oracle（Table 1） | closed-book + oracle | 可比 |
| 消融 | query-aware / 架构 / 指令微调 | 不做（可选做 query-aware 作为拓展） | 报告说明 |
| 解码 | greedy | greedy（temperature=0） | 一致 |

---

## 13. 决策记录表（A 填，变更即登记）

| 日期 | 决策项 | 决定 | 原因 / 备注 |
|---|---|---|---|
| 2026-10-02 | 复现类型 | 缩规模复现 | 课程要求 |
| 2026-10-02 | 样本 | 100 题，seed=42 | 分工文档 |
| 2026-10-02 | 位置 | 10 篇=1/5/10；5 篇=1/3/5 | 与官方文件对齐 |
| 2026-10-02 | 评分 | 答案包含率（官方口径） | 可复现 |
| 2026-10-02 | 基线 | closed-book + oracle 均做 | 用户决策；oracle 提供性能上限参照 |
| 2026-10-02 | 模型 | **MPT-30B-Instruct、LongChat-13B-16K、Qwen2.5-14B-Instruct** | 2026-10-03 确认 14B；部署=服务器 4090/5090 |
| 2026-10-02 | 备选模型 | **GLM-4-Flash** | 换模型时登记 |
| 2026-10-03 | 部署方式 | **服务器 GPU**，可满足三模型 | C 确认具体卡数/显存后在此补充 |
| ⬜ | 全量策略 | 待填：3 模型全量 / 1 全量+2 抽样（见 §8 降级方案） | 试跑后定 |
| ⬜ | 其他变更 | 待填 | — |
