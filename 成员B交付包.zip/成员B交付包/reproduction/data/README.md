# 成员 B 数据交接说明

交付日期：2026-10-07。依据 `configs/experiment_config.md` §3、§5、§6、§9、§10 与 `交接需求单-BCD.md` 实现。

已准备 100 题、八种条件的 800 条全量输入，以及固定前 10 题的 80 条试跑输入。数据与 prompt 静态校验已通过；全量输入已经备齐，**模型运行仍遵循 C 试跑 → D 评分 → A 核对 → 全量的顺序**。本交付没有模型输出、准确率、图表或试跑通过结论。

## 数据文件

以下路径相对于本目录。所有 JSON/JSONL 为 UTF-8 无 BOM，逐条 JSONL 用 LF 换行。

| 文件 | condition | num_docs | gold_position | gold_index（0 起算） | 条数 |
|---|---|---:|---|---:|---:|
| `10doc/首.jsonl` | `10doc_start` | 10 | 首 | 0 | 100 |
| `10doc/中.jsonl` | `10doc_middle` | 10 | 中 | 4 | 100 |
| `10doc/尾.jsonl` | `10doc_end` | 10 | 尾 | 9 | 100 |
| `5doc/首.jsonl` | `5doc_start` | 5 | 首 | 0 | 100 |
| `5doc/中.jsonl` | `5doc_middle` | 5 | 中 | 2 | 100 |
| `5doc/尾.jsonl` | `5doc_end` | 5 | 尾 | 4 | 100 |
| `closedbook.jsonl` | `closedbook` | 0 | null | null | 100 |
| `oracle.jsonl` | `oracle` | 1 | null | 0 | 100 |

`trial10/` 包含上述八个文件的前 10 条，文件布局相同，各 10 条，共 80 条。正式主实验只有六个位置条件；两个基线单独汇总。三模型共用同一套输入，默认全量 800 次/模型、2400 次合计，完整试跑 80 次/模型另计。

## 官方来源与本地路径

数据来自 Nelson F. Liu 等人的《Lost in the Middle: How Language Models Use Long Contexts》作者仓库（本地已有镜像）。当前官方仓库实际位于：

```text
../lost-in-the-middle-main/lost-in-the-middle-main/
```

上面路径相对于 `reproduction/`；原配置所写的 `official_repo/` 在本工作区不存在。生成器适配实际位置，未移动或修改官方仓库。

仅使用下列四个文件，每个 2655 条：

```text
qa_data/10_total_documents/nq-open-10_total_documents_gold_at_0.jsonl.gz
qa_data/10_total_documents/nq-open-10_total_documents_gold_at_4.jsonl.gz
qa_data/10_total_documents/nq-open-10_total_documents_gold_at_9.jsonl.gz
qa_data/nq-open-oracle.jsonl.gz
```

四份数据的所有源行均已核验：问题及参考答案逐行一致，gold 文档一致，10 篇三位置的干扰文档内容及相对顺序一致。所有源文件、配置和两份使用中的 prompt 模板 SHA256 记于 `sample_100/manifest.json`，十六个全量/试跑条件文件的条数及 SHA256 也在其中。

## 抽样和固定 ID

母本是 `gold_at_0`。使用以下算法，只抽一次，无放回，保留返回顺序：

```python
indices = random.Random(42).sample(range(2655), 100)
```

不按答案类型、模型表现等筛选、替换或重新抽样。前 10 个源行索引是：

```text
2619, 456, 102, 1126, 1003, 914, 571, 419, 2233, 356
```

源数据没有题目级 qid。使用 `nq-open-10-{src_row_index:05d}` 生成本组稳定 ID；例如源索引 42（第 43 行）对应 `nq-open-10-00042`。所有 `src_row_index`、`src_ctx_index` 从 **0** 起算。

| 清单文件 | 内容 |
|---|---|
| `sample_100/qids.txt` | 固定 100 个 qid，顺序是所有条件文件的输出顺序 |
| `sample_100/samples.jsonl` | 每个 qid 对应的源行索引、问题和完整参考答案数组 |
| `sample_100/manifest.json` | 抽样算法、100 个源索引、文件哈希、条件、基线字段和运行门槛 |
| `trial10/qids.txt` | 上述 qid 清单的前 10 个，试跑后不重新抽样 |

清单中没有机器路径、运行时间等影响 qid 的因素。源文件改变时，现有数据校验失败，不能继续把新的源行解释为旧 qid。

## 每条输入的接口

每条含配置 §10 的 qid、question、answers、num_docs、gold_position、gold_index、ctxs。额外提供 `condition`、记录级 `src_file` 和 `src_row_index`。

`ctxs` 保留官方文档的全部原始字段，追加 `src_file`、`src_row_index`、`src_ctx_index`。追溯时按以下顺序定位：

1. 相对于官方仓库根目录打开 `src_file`。
2. 取该文件从 0 起算的第 `src_row_index` 条记录。
3. 取其 `ctxs[src_ctx_index]`。

**src_ctx_index 是来源列表中的位置，不是派生输出列表的新位置。**例如 5 篇条件来自 gold_at_0，其 gold 的来源索引一直为 0，插到派生列表中间时仍为 0。

配置概括了文档的基本字段。实际干扰文档还有 `id`、`score`、`original_retrieval_index`；gold 没有这些字段，因此不依赖所有文档都有 id。生成器保留这些原始字段，校验时也检查其未被改写。

配置没有明确规定基线的 gold_position 序列化值，本交付将其设为 null，表示不参与首/中/尾比较。closedbook 无文档、gold_index=null；oracle 一篇证据、gold_index=0。使用新增的 condition 区分基线。这是对未定义字段的实现约定，模型、位置实验、prompt、参数及样本量保持配置所定取值。C/D 读取时须支持 JSON null，不可把 oracle 当作主实验的“首”条件。

## 构造方法与控制变量

10 篇：直接抽取官方 gold_at_0/4/9 的同一批源行，不自己重排。

5 篇：统一使用该题 gold_at_0 的 gold 和前四篇非 gold 文档，来源索引为 `[0,1,2,3,4]`。三个输出中的来源索引序列分别是 `[0,1,2,3,4]`、`[1,2,0,3,4]`、`[1,2,3,4,0]`。只有 gold 位置改变，四篇干扰文档的内容和相对顺序固定。

closedbook：保留问题与参考答案，ctxs 为空。oracle：直接取官方 oracle 同一题的唯一证据，未用其他内容代替证据。

所有条件共用问题、参考答案及样本顺序。保留 title/text 的完整内容、空白、大小写和标点，不翻译、不清洗、不截断；使用 isgold 识别证据，未用子串匹配重新标注文档。

## Prompt 与防止答案泄漏

`code/prompting.py` 的 `build_prompt(record)` 使用原封不动的配置模板：多文档及 oracle 用 qa.prompt，closedbook 用 closedbook_qa.prompt。两份模板均已与官方文件核验字节一致。

拼接格式是 `Document [i+1](Title: title) text`，文档间用换行连接；与官方读取逻辑一致，读取模板时只移除末尾换行。正文包含的换行仍保留。

模型消息仅包含上述 prompt。参考答案、gold 标记、qid、condition、来源、score 等留在审计记录中，**不作为 prompt 的额外内容**。gold 正文本身含答案是任务设计所需。880 条输入的 prompt 均对照官方源文本与模板核验，改变隐藏元信息不会改变 prompt。

`checks/prompt_examples/` 保存八种条件各一个完整 prompt。`checks/prompt_audit.jsonl` 保存 880 条 prompt 的指纹、字符数和静态检查结果；这不包含真实模型 token 用量。

## 生成、校验与回归检查

从 `reproduction/` 运行，Python 3.9+，仅标准库：

```bash
python code/prepare_data.py
python code/validate_data.py
python code/test_data_validation.py
```

PowerShell 命令、显式指定源目录、只读校验和 prompt 预览方法见 `../code/README.md`。

生成器先审计全部四份官方数据和模板，再生成候选内容；若目标文件已存在且与固定结果不同，则保留已有文件并退出。相同内容重复运行不会改写，原始数据与配置只读。

校验覆盖：固定 seed 与 qid、条数/字段/类型、所有条件问题与答案一致、唯一 gold 和位置、官方数据不重排、五篇取前四干扰、干扰顺序、全部原始文档字段、三元来源追溯、基线、试跑是全量前缀、prompt 与模板一致及隐藏元信息不进入 prompt。

验收输出为 `checks/validation_report.json` 和 `checks/validation_report.md`。源 gold 中参考答案出现情况作为诊断记录，不用于排除或替换题目。首次执行的 10 项回归检查全部通过，实际执行摘要保存于 `checks/regression_report.json`。

回归检查会故意制造截断、重排、错位、错误答案、重复 qid、试跑换题、闭书泄漏和错误来源索引，并更新文件哈希，验证校验器仍能发现问题；还检查字节一致的重复生成及保留不同已有文件。

## C / D / A 接手顺序与待办

1. C 从 `trial10/10doc/首.jsonl` 第一条进行单次调用；直接读取原始 JSONL，不复制 Markdown prompt 预览作为正式输入。
2. C 用实际模型快照、tokenizer 和消息包装统计所有条件的输入 token 数，检查输入 + 300 ≤ 部署窗口，关闭自动截断。`validation_report.json` 中这项状态明确为 `pending_member_C`；字符数不能替代 token 数。
3. C 先跑 10doc 三位置各 10 题，共 30 次/模型。完整八条件试跑为 80 次/模型，按配置和组内安排执行。
4. C 保留输入全部字段并追加真实输出、模型版本、完整 prompt/指纹、usage、耗时、配置快照与时间戳。断点续跑键应包含模型版本及 condition、qid。
5. D 按配置 §7 的首行＋SQuAD 归一化＋子串规则评分；六个位置条件按 num_docs/gold_position 汇总，closedbook/oracle 单独分组。
6. A 核对试跑条件及固定清单后，再开始 100 题全量推理；任何实验设置变更依照配置登记。

## 数据来源

官方数据和 prompt 来自作者本地仓库镜像；所有样本内容均为源数据抽取或按契约派生，没有编造。

配置、官方仓库、模型部署、评分代码及其他成员负责的结果文件均未由本数据任务改写。
