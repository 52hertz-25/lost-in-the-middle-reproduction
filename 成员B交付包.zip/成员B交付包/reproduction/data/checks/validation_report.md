# 成员 B 数据验收记录

状态：**通过**（数据与 prompt 静态校验）。

- 固定样本：100 题，seed=42；试跑为固定前 10 题。
- 全量输入：800 条；试跑输入：80 条；源记录审计：10620 条。
- 实际通过检查：43301 项断言。
- 所有文档完整保留，三位置干扰文档内容与顺序一致。
- 每篇文档的源文件、源记录行、源 ctx 索引均验证通过。
- 880 条 prompt 均与官方模板和源文本匹配，答案/审计元信息不影响 prompt。

| 文件 | 条数 | 最短 prompt 字符数 | 最长 prompt 字符数 | 最长样本 qid |
|---|---:|---:|---:|---|
| `10doc/首.jsonl` | 100 | 5838 | 7329 | `nq-open-10-01718` |
| `10doc/中.jsonl` | 100 | 5838 | 7329 | `nq-open-10-01718` |
| `10doc/尾.jsonl` | 100 | 5838 | 7329 | `nq-open-10-01718` |
| `5doc/首.jsonl` | 100 | 2726 | 3976 | `nq-open-10-01718` |
| `5doc/中.jsonl` | 100 | 2726 | 3976 | `nq-open-10-01718` |
| `5doc/尾.jsonl` | 100 | 2726 | 3976 | `nq-open-10-01718` |
| `closedbook.jsonl` | 100 | 49 | 112 | `nq-open-10-01857` |
| `oracle.jsonl` | 100 | 302 | 1379 | `nq-open-10-01718` |
| `trial10/10doc/首.jsonl` | 10 | 6029 | 6992 | `nq-open-10-01126` |
| `trial10/10doc/中.jsonl` | 10 | 6029 | 6992 | `nq-open-10-01126` |
| `trial10/10doc/尾.jsonl` | 10 | 6029 | 6992 | `nq-open-10-01126` |
| `trial10/5doc/首.jsonl` | 10 | 2845 | 3519 | `nq-open-10-01126` |
| `trial10/5doc/中.jsonl` | 10 | 2845 | 3519 | `nq-open-10-01126` |
| `trial10/5doc/尾.jsonl` | 10 | 2845 | 3519 | `nq-open-10-01126` |
| `trial10/closedbook.jsonl` | 10 | 55 | 83 | `nq-open-10-02233` |
| `trial10/oracle.jsonl` | 10 | 325 | 790 | `nq-open-10-00356` |

字符数用于定位长输入，**不是 token 数**。
实际 tokenizer、消息包装后的输入 token 数、输出预留 300 tokens 与部署窗口的检查待 C 完成。
本记录没有模型调用、评分、U 型曲线或试跑通过结论。
C 先单条调用和试跑，D 评分，A 核对通过后再运行全量。

详见 `validation_report.json`、`prompt_audit.jsonl` 和 `../README.md`。
