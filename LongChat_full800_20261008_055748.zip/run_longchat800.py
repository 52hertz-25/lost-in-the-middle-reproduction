import os
import sys
import json
import time
import hashlib
import subprocess
import zipfile
from pathlib import Path

import torch
import transformers
from transformers import (
    AutoConfig, AutoTokenizer, AutoModelForCausalLM,
    BitsAndBytesConfig, GenerationConfig,
)

BASE = Path("/root/autodl-tmp/p35")
PROJECT = BASE / "成员B交付包/reproduction"
MODEL = BASE / "longchat-13b-16k"
OUT = PROJECT / "results/raw/longchat-13b-16k/full100"
PROMPTS = PROJECT / "results/prompts/longchat-full100"
REV = "70e2e38b82f1e25d8b90b50fbfc2361123bef45f"
CONDITIONS = [
    "10doc/中.jsonl", "10doc/尾.jsonl", "10doc/首.jsonl",
    "5doc/中.jsonl", "5doc/尾.jsonl", "5doc/首.jsonl",
    "closedbook.jsonl", "oracle.jsonl",
]

def read_rows(path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

os.chdir(PROJECT)
assert torch.cuda.is_available(), "GPU不可用"
assert MODEL.is_dir(), f"模型目录不存在: {MODEL}"

print("检查权重文件，可能需要几分钟...", flush=True)
index = json.loads((MODEL / "pytorch_model.bin.index.json").read_text())
shards = sorted(set(index["weight_map"].values()))
assert len(shards) == 3, f"权重分片数量异常: {shards}"

for name in shards:
    path = MODEL / name
    assert path.is_file(), f"缺少权重: {path}"
    assert zipfile.is_zipfile(path), f"权重上传不完整: {name}"
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        assert bad is None, f"权重损坏: {name}, {bad}"
    print("权重检查通过:", name, flush=True)

record = MODEL / "download_revision.json"
assert record.exists(), "缺少 download_revision.json"
revision = json.loads(record.read_text(encoding="utf-8"))
assert revision["repo_id"] == "lmsys/longchat-13b-16k"
assert revision["revision"] == REV, "模型快照与计划不一致"

# 寻找八个条件均包含100条记录的数据目录。
candidates = []
for oracle in (PROJECT / "data").rglob("oracle.jsonl"):
    root = oracle.parent
    try:
        groups = [read_rows(root / name) for name in CONDITIONS]
    except (OSError, ValueError):
        continue
    if all(len(rows) == 100 for rows in groups):
        candidates.append(root)

assert len(candidates) == 1, (
    f"完整数据目录应唯一，实际找到: {candidates}。"
    "停止运行，请把这条信息发给我。"
)
DATA = candidates[0]
print("完整数据目录:", DATA, flush=True)

qid_sets = []
for name in CONDITIONS:
    rows = read_rows(DATA / name)
    qids = [r["qid"] for r in rows]
    assert len(set(qids)) == 100, f"重复qid: {name}"
    qid_sets.append(set(qids))
assert all(s == qid_sets[0] for s in qid_sets), "条件之间qid不一致"

OUT.mkdir(parents=True, exist_ok=True)
PROMPTS.mkdir(parents=True, exist_ok=True)

tokenizer = AutoTokenizer.from_pretrained(
    MODEL, local_files_only=True, use_fast=False,
)
config = AutoConfig.from_pretrained(MODEL, local_files_only=True)
rope = config.rope_scaling or {}
assert rope.get("factor") == 8.0, f"RoPE配置异常: {rope}"
assert rope.get("rope_type", rope.get("type")) == "linear"
WINDOW = 16384

# 固定单用户轮次，不添加系统消息；记录模板以便复现。
def wrap(prompt):
    return f"USER: {prompt} ASSISTANT:"

settings = {
    "model_id": "lmsys/longchat-13b-16k",
    "revision": REV,
    "quantization": "NF4, double quantization",
    "compute_dtype": "bfloat16",
    "attention": "sdpa",
    "prompt_wrapper": "USER: {prompt} ASSISTANT:",
    "system_message": None,
    "do_sample": False,
    "num_beams": 1,
    "max_new_tokens": 300,
    "context_window": WINDOW,
    "torch_version": torch.__version__,
    "transformers_version": transformers.__version__,
}
settings_id = hashlib.sha256(
    json.dumps(settings, sort_keys=True).encode()
).hexdigest()

jobs = []
maximum = 0
for name in CONDITIONS:
    source = DATA / name
    target = PROMPTS / name
    target.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        sys.executable, "code/prompting.py",
        "--input", str(source),
        "--output", str(target),
    ], check=True)

    rows = read_rows(target)
    assert len(rows) == 100, f"提示词条数异常: {name}"
    source_hash = sha(source)
    for row in rows:
        prompt = wrap(row["prompt"])
        tokens = tokenizer(prompt, return_tensors="pt")
        length = tokens["input_ids"].shape[1]
        maximum = max(maximum, length)
        assert length + 300 <= WINDOW, (
            f"输入超出窗口: {name}, {row['qid']}, {length}"
        )
        jobs.append((name, source_hash, row, prompt, length))

assert len(jobs) == 800
print("输入总数:", len(jobs), flush=True)
print("最大输入tokens:", maximum, flush=True)

# 读取已完成结果，防止重复或混用不同设置。
done = {}
for name in CONDITIONS:
    result_file = OUT / name
    old = read_rows(result_file) if result_file.exists() else []
    completed = {}
    for row in old:
        assert row["settings_id"] == settings_id, "已有结果配置不一致"
        assert row["qid"] not in completed, "已有结果有重复qid"
        completed[row["qid"]] = row
    done[name] = completed

for name, source_hash, row, prompt, length in jobs:
    old = done[name].get(row["qid"])
    if old:
        assert old["input_sha256"] == source_hash, "数据已变化"
        assert old["wrapped_prompt_sha256"] == hashlib.sha256(
            prompt.encode()
        ).hexdigest(), "提示词已变化"

finished = sum(len(rows) for rows in done.values())
print(f"已完成: {finished}/800", flush=True)
if finished == 800:
    print("800条已全部完成，无需重复运行:", OUT)
    sys.exit(0)

print("加载LongChat...", flush=True)
model = AutoModelForCausalLM.from_pretrained(
    MODEL,
    local_files_only=True,
    quantization_config=BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
    ),
    torch_dtype=torch.bfloat16,
    device_map={"": 0},
    attn_implementation="sdpa",
)
model.eval()

generation = GenerationConfig(
    do_sample=False,
    num_beams=1,
    max_new_tokens=300,
    eos_token_id=tokenizer.eos_token_id,
    pad_token_id=tokenizer.pad_token_id
        if tokenizer.pad_token_id is not None
        else tokenizer.eos_token_id,
)

first = True
for name, source_hash, row, prompt, length in jobs:
    if row["qid"] in done[name]:
        continue

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
    torch.cuda.synchronize()
    started = time.perf_counter()
    with torch.inference_mode():
        output = model.generate(
            **inputs, generation_config=generation,
        )
    torch.cuda.synchronize()
    latency = time.perf_counter() - started
    new_tokens = output[0, length:]
    answer = tokenizer.decode(
        new_tokens, skip_special_tokens=True,
    ).strip()
    assert answer, f"空回答: {name}, {row['qid']}"

    saved = dict(row)
    saved.update({
        "model_id": settings["model_id"],
        "model_revision": REV,
        "source_file": name,
        "input_sha256": source_hash,
        "wrapped_prompt": prompt,
        "wrapped_prompt_sha256": hashlib.sha256(
            prompt.encode()
        ).hexdigest(),
        "model_answer": answer,
        "first_line": answer.splitlines()[0],
        "input_tokens": length,
        "output_tokens": len(new_tokens),
        "latency_s": latency,
        "settings_id": settings_id,
        "config_snapshot": settings,
    })

    result_file = OUT / name
    result_file.parent.mkdir(parents=True, exist_ok=True)
    with result_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(saved, ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())

    finished += 1
    if first:
        print("\n第一条完整回答:", answer, "\n", flush=True)
        first = False
    print(
        f"[{finished}/800] {name} {row['qid']} "
        f"{latency:.2f}s {answer[:100]}",
        flush=True,
    )

for name in CONDITIONS:
    rows = read_rows(OUT / name)
    assert len(rows) == 100
    assert len({r["qid"] for r in rows}) == 100
print("800条全量运行完成，结果目录:", OUT, flush=True)
