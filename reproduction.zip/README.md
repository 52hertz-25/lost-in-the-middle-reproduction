# 复现《Lost in the Middle: How Language Models Use Long Contexts》

> 复现类型标签：**缩规模复现**（减少样本与文档数，保留比较逻辑；数值不与原文硬对齐，检验趋势）

## 论文与仓库

| 项 | 内容 |
|---|---|
| 论文 | Liu et al., "Lost in the Middle: How Language Models Use Long Contexts", TACL 2024, vol. 12, pp. 157–173 |
| DOI | https://doi.org/10.1162/tacl_a_00638 |
| arXiv | https://arxiv.org/abs/2307.03172 |
| 官方代码/数据 | 已解压到 `official_repo/lost-in-the-middle-main/`（作者仓库 https://github.com/nelsonliu-ai/lost-in-the-middle 的镜像） |

## 本组要复现什么（一句话）

> 在多文档问答（Multi-document QA）中，把**唯一含答案的证据文档**放到上下文**首 / 中 / 尾**三个位置，比较同一模型的回答准确率；检验"相关信息在中间时性能显著下降（Lost in the Middle / U 型曲线）"这一核心结论。对照：5 篇、10 篇两种上下文长度；闭书（closed-book）基线必做。

对应课程登记表：**P35 · Lost in the Middle（资源类型 L：生成/评审服务）**，限定任务"同一证据移到上下文首、中、尾"。

## 目录结构

```
reproduction/
├── README.md                     ← 本文件（项目总览，全组先读）
├── _source/                      ← 原始材料（论文 PDF、课程说明、分工文档）
├── official_repo/                ← 作者官方仓库（数据 + 脚本 + prompt 模板，只读参考）
├── docs/
│   ├── 成员A任务指导.md          ← A 的详细任务书（时间线、动作、交接需求）
│   └── 模型选型方案.md           ← 模型选项 + 理由 + 决策树（A 先读此文件做决策）
├── configs/
│   ├── experiment_config.md      ← 实验配置总纲（组内"契约"，B/C/D 全部依据它干活）
│   ├── paper_reference.md        ← 论文速查与原文定位（写作引用用）
│   └── prompts/                  ← 官方 prompt 模板副本（含来源）
├── data/                         ← （B 产出）输入文件、固定 ID 清单、data/README.md
├── code/                         ← （B/C/D 产出）数据处理、调用、评分代码
├── results/                      ← （C/D 产出）原始输出、评分表、图表
├── report/                       ← （A 整合）report.pdf、contributions.md
└── slides/                       ← （D 主导）slides.pptx、slides.pdf
```

## 关键约定（全组必须遵守，详见 configs/experiment_config.md）

1. **固定模型版本、prompt 模板、生成参数（temperature=0）**，中途不换。
2. **单变量实验**：只改变"证据文档位置"和"文档总数"；移动证据时**其余干扰文档相对顺序保持不变**。
3. **评分口径**：取模型输出**首行** → strip → SQuAD 归一化 → 任一参考答案是否出现（与官方 `best_subspan_em` 一致）。
4. **每条结果留证据**：样本 ID、参考答案、模型输出、配置参数、token 用量、耗时。
5. **不得编造日志/结果**；使用 AI 与作者代码需在报告和 contributions.md 中如实说明。

## 当前进度（由 A 维护）

- [x] 原理论文、课程说明、分工文档已读；官方仓库已解压
- [x] 实验配置初稿、论文速查、模型选型方案已有
- [x] A 已决策：模型 = MPT-30B-Instruct / LongChat-13B-16K / Qwen2.5-14B-Instruct（备选 GLM-4-Flash）；基线closed-book + oracle 均做（登记于 experiment_config.md §13）
- [ ] B：10 题小样数据 → C：30 次试跑 → D：试跑评分（9/29 后 ~ 10/11 完成）
- [ ] 10/11 半页选题与试跑记录（A 汇总）
- [ ] 100 题完整实验（10/11 ~ 10/24）
- [ ] 10/24 一页中期记录（A 汇总）；10/27 课后按课程要求提交
- [ ] 11/21 组内全部完成；11/22 24:00 延河课堂最终提交；11/24 或 12/1 汇报

## 复现判定（不要求数值对齐）

- 首/尾准确率明显高于中间位置 → 复现出 U 型趋势即视为成功；
- 10 篇条件下中间位置是否接近甚至低于 closed-book 基线 → 与论文 Fig 5 对照并解释；
- 数值差异（模型不同、样本缩减）在报告"设置差异表"中如实说明。
