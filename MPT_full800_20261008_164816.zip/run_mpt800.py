import os
import sys
import json
import time
import hashlib
import subprocess
import zipfile
from pathlib import Path
from datetime import datetime
import llama_cpp
from llama_cpp import Llama

BASE = Path("/root/autodl-tmp/p35")
PROJECT = BASE / "成员B交付包/reproduction"
MODEL_DIR = BASE / "mpt-30b-instruct-gguf"
MODEL = MODEL_DIR / "mosaicml-mpt-30b-instruct-Q4_K_M.gguf"
OUT = PROJECT / "results/raw/mpt-30b-instruct-gguf/full100"
PROMPTS = PROJECT / "results/prompts/mpt-full100"
REV = "852aef733e0ccd205564d88d8a73f44229a340d8"
NAMES = [
    "10doc/中.jsonl", "10doc/尾.jsonl", "10doc/首.jsonl",
    "5doc/中.jsonl", "5doc/尾.jsonl", "5doc/首.jsonl",
    "closedbook.jsonl", "oracle.jsonl",
]

def rows(path):
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def wrap(prompt):
    return (
        "Below is an instruction that describes a task. "
        "Write a response that appropriately completes the request.\n\n"
        f"### Instruction:\n{prompt}\n\n### Response:\n"
    )

assert MODEL.is_file(), "找不到MPT模型"
record = MODEL_DIR / "download_revision.json"
assert record.is_file(), "缺少模型下载快照记录"
assert REV in record.read_text(encoding="utf-8"), "模型快照记录不一致"

os.chdir(PROJECT)
candidates = []
for oracle in (PROJECT / "data").rglob("oracle.jsonl"):
    root = oracle.parent
    try:
        groups = [rows(root / name) for name in NAMES]
    except (OSError, ValueError):
        continue
    if all(len(group) == 100 for group in groups):
        candidates.append(root)
assert len(candidates) == 1, f"完整数据目录不唯一或缺失: {candidates}"
DATA = candidates[0]

qid_sets = [{r["qid"] for r in rows(DATA / name)} for name in NAMES]
assert all(len(s) == 100 for s in qid_sets), "存在重复qid"
assert all(s == qid_sets[0] for s in qid_sets), "各组qid不一致"

OUT.mkdir(parents=True, exist_ok=True)
PROMPTS.mkdir(parents=True, exist_ok=True)

print("计算模型SHA256，请稍等...", flush=True)
model_hash = digest(MODEL)
hardware = subprocess.check_output([
    "nvidia-smi", "--query-gpu=name,memory.total,driver_version",
    "--format=csv,noheader",
], text=True).strip()

settings = {
    "model_id": "mosaicml/mpt-30b-instruct",
    "conversion_repo": "maddes8cht/mosaicml-mpt-30b-instruct-gguf",
    "conversion_revision": REV,
    "model_sha256": model_hash,
    "quantization": "GGUF Q4_K_M",
    "backend": "llama-cpp-python",
    "backend_version": llama_cpp.__version__,
    "hardware": hardware,
    "n_ctx": 8192,
    "n_gpu_layers": -1,
    "n_batch": 256,
    "n_threads": 10,
    "temperature": 0,
    "repeat_penalty": 1.0,
    "max_tokens": 300,
    "seed": 42,
    "prompt_wrapper": wrap("{prompt}"),
    "system_message": None,
}
settings_id = hashlib.sha256(
    json.dumps(settings, sort_keys=True).encode()
).hexdigest()

(OUT / "run_config.json").write_text(
    json.dumps(settings, ensure_ascii=False, indent=2),
    encoding="utf-8",
)
(BASE / "mpt_environment.txt").write_text(
    subprocess.check_output(
        [sys.executable, "-m", "pip", "freeze"], text=True
    ),
    encoding="utf-8",
)

jobs = []
for name in NAMES:
    source = DATA / name
    target = PROMPTS / name
    target.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        sys.executable, "code/prompting.py",
        "--input", str(source), "--output", str(target),
    ], check=True)
    group = rows(target)
    assert len(group) == 100
    assert {r["qid"] for r in group} == qid_sets[0]
    source_hash = digest(source)
    for row in group:
        prompt = wrap(row["prompt"])
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()
        jobs.append((name, source_hash, row, prompt, prompt_hash))
assert len(jobs) == 800

done = {}
for name in NAMES:
    path = OUT / name
    old = rows(path) if path.exists() else []
    completed = {}
    for r in old:
        assert r["settings_id"] == settings_id, "已有结果配置不一致"
        assert r["qid"] not in completed, "已有结果存在重复qid"
        completed[r["qid"]] = r
    done[name] = completed

for name, source_hash, row, prompt, prompt_hash in jobs:
    old = done[name].get(row["qid"])
    if old:
        assert old["input_sha256"] == source_hash, "数据已变化"
        assert old["wrapped_prompt_sha256"] == prompt_hash, "提示词已变化"

finished = sum(len(group) for group in done.values())
print(f"已有结果: {finished}/800", flush=True)

if finished < 800:
    print("加载模型...", flush=True)
    model = Llama(
        model_path=str(MODEL),
        n_gpu_layers=-1,
        n_ctx=8192,
        n_batch=256,
        n_threads=10,
        seed=42,
        verbose=True,
    )
    assert model.metadata.get("general.architecture") == "mpt"
    assert int(model.metadata["mpt.context_length"]) >= 8192

    maximum = 0
    for name, source_hash, row, prompt, prompt_hash in jobs:
        length = len(model.tokenize(prompt.encode(), add_bos=True))
        maximum = max(maximum, length)
        assert length + 300 <= model.n_ctx(), (
            f"输入超出窗口: {name} {row['qid']} {length}"
        )
    print("800条输入长度检查通过，最大tokens:", maximum, flush=True)

    first = True
    for name, source_hash, row, prompt, prompt_hash in jobs:
        if row["qid"] in done[name]:
            continue
        model.reset()
        started = time.perf_counter()
        result = model(
            prompt,
            max_tokens=300,
            temperature=0,
            repeat_penalty=1.0,
            echo=False,
        )
        latency = time.perf_counter() - started
        answer = result["choices"][0]["text"].strip()

        saved = dict(row)
        saved.update({
            "model_id": settings["model_id"],
            "model_answer": answer,
            "first_line": answer.splitlines()[0] if answer else "",
            "source_file": name,
            "input_sha256": source_hash,
            "wrapped_prompt": prompt,
            "wrapped_prompt_sha256": prompt_hash,
            "input_tokens": result["usage"]["prompt_tokens"],
            "output_tokens": result["usage"]["completion_tokens"],
            "finish_reason": result["choices"][0]["finish_reason"],
            "latency_s": latency,
            "settings_id": settings_id,
            "config_snapshot": settings,
        })
        path = OUT / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(saved, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        done[name][row["qid"]] = saved
        finished += 1
        if first:
            print("第一条完整回答:", answer, flush=True)
            first = False
        print(
            f"[{finished}/800] {name} {row['qid']} "
            f"{latency:.2f}s {answer[:100]}",
            flush=True,
        )
    model.close()

empty = 0
total_latency = 0
for name in NAMES:
    group = rows(OUT / name)
    assert len(group) == 100
    assert {r["qid"] for r in group} == qid_sets[0]
    assert all(r["settings_id"] == settings_id for r in group)
    empty += sum(not r["model_answer"].strip() for r in group)
    total_latency += sum(r["latency_s"] for r in group)
print("800条全量运行完成，空回答:", empty, flush=True)

summary = {
    "total": 800,
    "empty_answers": empty,
    "inference_minutes": total_latency / 60,
    "settings_id": settings_id,
}
(OUT / "validation.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
archive = BASE / f"MPT_full800_{stamp}.zip"
items = [
    OUT, PROMPTS, PROJECT / "data", PROJECT / "configs",
    PROJECT / "code", BASE / "run_mpt800.py",
    BASE / "mpt_environment.txt", record, MODEL_DIR / "README.md",
]
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as z:
    for item in items:
        if not item.exists():
            continue
        files = sorted(item.rglob("*")) if item.is_dir() else [item]
        for file in files:
            if file.is_file() and "__pycache__" not in file.parts:
                z.write(file, str(file.relative_to(BASE)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None, "ZIP完整性检查失败"

checksum = Path(str(archive) + ".sha256")
checksum.write_text(
    f"{digest(archive)}  {archive.name}\n", encoding="utf-8"
)
print("打包完成:", archive, flush=True)
print("校验文件:", checksum, flush=True)
